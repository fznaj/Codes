#ifndef VIEW_H
#define VIEW_H

#include <QWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QTableWidget>

#include <board.h>
#include <game.h>
#include <observer.h>

/**
 * @brief The View class the view of the game
 */
class View : public QWidget,public Observer {
    Q_OBJECT

    /**
     * @brief board the Board
     */
    Board *board;

    /**
     * @brief game the Game
     */
    Game* game;

    /**
     * @brief widthView the width of the board
     */
    int widthView;

    /**
     * @brief heightView the height of the board
     */
    int heightView;

    /**
     * @brief numberColors the number of the colors
     */
    int numberColors;

    /**
     * @brief highScore the highScore for a given height, a given width
     * and a given number of colors
     */
    int highScore;

    QTableWidget *table;

    QComboBox *size;
    QComboBox *nbColors;

    QVBoxLayout *option;
    QVBoxLayout *optionBox;

    QHBoxLayout *layout;

    QLabel *scoreLbl;
    QLabel *highScoreLbl;
    QLabel *nbMinStepsLbl;

    QLCDNumber *score;
    QLCDNumber *hScore;
    QLCDNumber *nbMinSteps;

public:
    /**
     * @brief View Constructor
     * @param parent QWidget
     */
    explicit View(QWidget* parent =0);

    /**
     *Destuctor of the class View
     */
    ~View();

    /**
     * @brief refresh repaints the view and updates it
     */
    void refresh();
    
protected:
    /**
     * @brief paintEvent paints the grid
     */
    void paintEvent(QPaintEvent*);

    /**
     * @brief drawCell draws a cell at (x,y) with the color type
     * @param x the abscissa of the cell
     * @param y the ordinate of the cell
     * @param type the color of the cell
     */
    void drawCell( int x, int y, int type);

    /**
     * @brief readFile reads from the score file
     * and stores the high score
     */
    void readFile();

    /**
     * @brief writeToFile updates the high score at the end of the game
     * if it's beaten
     * @param highScore the new high score
     */
    void writeToFile(int highScore);

public slots:

    /**
     * @brief congrats displays a congratulations message
     * when the player wins
     */
    void congrats();

    /**
     * @brief gameOver displays a game over message
     * when the player loses
     */
    void gameOver();

    /**
     * @brief onNewGame starts a new game
     */
    void onNewGame();

    /**
     * @brief initAll reinitializes the game
     */
    void initAll();

    /**
     * @brief params parameters set by the player
     */
    void params();

    /**
     * @brief cellSelected floods the cell selected and
     * the adjacent cells
     * @param x the abscissa of the cell
     * @param y the ordinate of the cell
     */
    void cellSelected(int x,int y);
};


#endif // VIEW_H
