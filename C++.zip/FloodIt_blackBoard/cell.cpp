#include "cell.h"

Cell::Cell(int x, int y, int color):x(x),y(y),color(color)
{
}

Cell::Cell()
{
}

int Cell::getX()const{
    return x;
}

int Cell::getY()const{
    return y;
}

int Cell::getColor()const{
    return color;
}

void Cell::setColor(int newColor){
    color=newColor;
}
