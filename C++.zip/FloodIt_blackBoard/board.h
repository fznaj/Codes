#ifndef BOARD_H
#define BOARD_H

#include "cell.h"
#include <vector>
#include <iostream>

using namespace std;
/**
 * @brief The Board class represents the grid
 */
class Board
{

    /**
     * @brief height : height of the board
     */
    int height;

    /**
     * @brief width : width of the board
     */
    int width;

    /**
     * @brief nbColors : number of the colors
     */
    int nbColors;

    /**
     * @brief winner : bool defining if a player is a winner or not
     */
    bool winner;

    /**
     * @brief gameover : true if the player lost, false otherwise
     */
    bool gameover;

    /**
     * @brief minNbSteps : minimum of steps required to win the game
     * given a specific height, a specific width and a specific
     * number of colors
     */
    int minNbSteps;

    /**
     * @brief nbSteps : score or number of steps or clicks of the player
     */
    int nbSteps;

    /**
     * @brief grid :  the board , which is a vector of vectors of tuple of Cell, bool, bool.
     * The first bool represents if a cell is visited. The second if it's flooded.
     */
    std::vector<std::vector<std::tuple<Cell,bool,bool>>> grid;

    static const int DEFAULT_HEIGHT = 22;
    static const int DEFAULT_WIDTH = 22;
    static const int DEFAULT_NB_COLORS = 8;

public:
    /**
     * @brief Board : Constructor with parameters
     * @param boardHeight : height of the board
     * @param boardWidth : width of the board
     * @param nbInitColors : number of colors
     */
    Board(int boardHeight=DEFAULT_HEIGHT,int boardWidth=DEFAULT_WIDTH,int nbInitColors= DEFAULT_NB_COLORS);

    /**
     * @brief initGrid :
     *          - initializes the attributes
     *          - calculates the minimum number of steps
     *          - clears the grid and resizes it
     *          - sets the visited and flooded booleans of all
     *           the cells to false and sets the cell at (0,0) to flooded
     */
    void initGrid();

    /**
     * @brief init initializes the attributes
     */
    void init();

    /**
     * @brief getHeight getter of the height
     * @return an integer representing the height of the board
     */
    int getHeight() const;

    /**
     * @brief getNbColors getter of the number of colors
     * @return the number of the colors used in the game
     */
    int getNbColors() const;

    /**
     * @brief getWidth getter of the width
     * @return an integer representing the width of the board
     */
    int getWidth()const;

    /**
     * @brief getScore gets the number of steps
     * @return an integer representing the score of the player
     */
    int getScore();

    /**
     * @brief getMinSteps gets the minimum number of steps required
     *  for a given height, a given width and a given number of colors
     * @return the minimum number of steps
     */
    int getMinSteps();

    /**
     * @brief setScore sets the score of the user to a new score
     * @param newScore the new score
     */
    void setScore(int newScore);

    /**
     * @brief isWinner checks if the player is winner
     * @return true if winner, false otherwise
     */
    bool isWinner();

    /**
     * @brief isGameOver checks if the game is over
     * @return true if gameover, false otherwise
     */
    bool isGameOver();

    /**
     * @brief checkGameOver checks if the grid has got one same color.
     *      - if it's true and the score is less than or equal to the minimum
     *          number of steps required , it sets winner to true, else it
     *          sets gameover to true
     */
    void checkGameOver();

    /**
     * @brief calculateNbSteps calculates the minimum number of steps
     */
    void calculateNbSteps();

    /**
     * @brief getCellColor gets the color of the cell at (x,y)
     * @param x the abscissa of the cell
     * @param y the ordinate of the cell
     * @return an integer between 1 and 8 representing the color of the cell
     */
    int getCellColor(int x, int y);

    /**
     * @brief setCellColor sets the cell at (x,y) to the new color
     * @param x the abscissa of the cell
     * @param y the ordinate of the cell
     * @param type the new color
     */
    void setCellColor(int x, int y,int type);

    /**
     * @brief floodFill floods the cell at (x,y) and the adjacent cells with the colour type :
     *          - checks if cell is in the grid
     *          - sets all the cells to visited
     *          - if the cell is flooded it's set to the color id
     *          - if the cell's got the same color as id it's set to flooded
     * @param x abscissa
     * @param y ordinate
     * @param id the new color
     */
    void floodFill(int x, int y, int id);

    /**
     * @brief initVisited : initializes the visited bool of each cell to false
     */
    void initVisited();

};

#endif // BOARD_H
