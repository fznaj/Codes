#include "view.h"
#include "cell.h"

#include <QApplication>
#include <QPainter>
#include <QStringList>
#include <QInputDialog>
#include <QMessageBox>
#include <QComboBox>
#include <QFile>
#include <QTextStream>
#include <QTableWidget>
#include <QHeaderView>
#include <QTableWidgetItem>
#include <QDialogButtonBox>

View::View( QWidget* parent ) : QWidget( parent ) {

    QFont font;
    font.setPointSize(10);
    font.setBold(true);

    scoreLbl=new QLabel("Score: ");
    scoreLbl->setFont(font);
    scoreLbl->setStyleSheet("color: white;");

    score=new QLCDNumber(3);
    score->setSegmentStyle(QLCDNumber::Flat);
    score->setStyleSheet("color: white;");

    highScoreLbl = new QLabel("High Score: ");
    highScoreLbl->setFont(font);
    highScoreLbl->setStyleSheet("color: white;");

    hScore = new QLCDNumber(3);
    hScore->setSegmentStyle(QLCDNumber::Flat);
    hScore->setStyleSheet("color: white;");

    nbMinStepsLbl=new QLabel("Minimum Steps: ");
    nbMinStepsLbl->setFont(font);
    nbMinStepsLbl->setStyleSheet("color: white;");

    nbMinSteps=new QLCDNumber(3);
    nbMinSteps->setSegmentStyle(QLCDNumber::Flat);
    nbMinSteps->setStyleSheet("color: white;");

    option = new QVBoxLayout();
    option->setAlignment(Qt::AlignRight);
    option->setSpacing(4);
    option->addWidget(scoreLbl);
    option->addWidget(score);
    option->addWidget(nbMinStepsLbl);
    option->addWidget(nbMinSteps);

    optionBox = new QVBoxLayout();
    optionBox->setAlignment(Qt::AlignRight);
    optionBox->addWidget(highScoreLbl);
    optionBox->addWidget(hScore);

    onNewGame();

    layout = new QHBoxLayout();
    layout->addItem(optionBox);
    layout->addWidget(table);
    layout->addItem(option);
    setLayout(layout);

    setWindowTitle(tr("Flood It"));
    setStyleSheet("background-color: black;");
    setFixedSize(900,700);
}

void View::onNewGame()
{
    QDialog * dialog = new QDialog();
    dialog->setWindowTitle("Floot It");
    QVBoxLayout * vbox = new QVBoxLayout();

    QLabel *sizeLabel = new QLabel("Please choose the size of the grid");

    QLabel *nbColorsLabel = new QLabel("Please choose the number of the colors");

    size = new QComboBox;
    QStringList sizeList=(QStringList()<<"2x2"<<"10x5"<<"13x13"<<"18x15"<<"22x22");
    size->addItems(sizeList);

    nbColors = new QComboBox;
    QStringList colorsList=(QStringList()<<"2"<<"3"<<"4"<<"5"<<"6"<<"7"<<"8");
    nbColors->addItems(colorsList);

    QDialogButtonBox * buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok
                                                        | QDialogButtonBox::Cancel);

    connect(buttonBox, SIGNAL(accepted()), dialog, SLOT(accept()));
    connect(buttonBox, SIGNAL(rejected()), dialog, SLOT(reject()));

    vbox->addWidget(sizeLabel);
    vbox->addWidget(size);
    vbox->addWidget(nbColorsLabel);
    vbox->addWidget(nbColors);
    vbox->addWidget(buttonBox);

    dialog->setLayout(vbox);
    dialog->setFixedSize(300,200);

    int result = dialog->exec();

    if(result == QDialog::Accepted)
    {
        params();
    }else{
        QApplication::quit();
    }
}

void View::initAll()
{
    game->initGame();
    readFile();
    game->notify();
}

void View::params(){
    if(size->currentText()=="2x2"){
        heightView=2;
        widthView=2;
    }else if(size->currentText()=="10x5"){
        heightView=10;
        widthView=5;
    }else if(size->currentText()=="13x13"){
        heightView=13;
        widthView = 13;
    }else if(size->currentText()=="18x15"){
        heightView=18;
        widthView=15;
    }else if(size->currentText()=="22x22"){
        heightView=22;
        widthView=22;
    }else{
        heightView=22;
        widthView=22;
    }
    numberColors= nbColors->currentText().at(0).digitValue();

    try{
        board = new Board(heightView,widthView,numberColors);
    }catch(std::invalid_argument e){
        std::cout << e.what() << std::endl;
    }
    game = new Game(board, this, this);
    game->addObserver(this);
    game->initGame();
    readFile();

    table=new QTableWidget(heightView,widthView,this);
    table->setRowCount(heightView);
    table->setColumnCount(widthView);
    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);
    table->horizontalHeader()->setDefaultSectionSize(30);
    table->verticalHeader()->setDefaultSectionSize(30);
    table->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    table->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);

    connect( table, SIGNAL( cellClicked(int,int)),
             this, SLOT( cellSelected( int, int )));

    connect(game,SIGNAL(started(int)),nbMinSteps,SLOT(display(int)));
    connect(game, SIGNAL(scoreChanged(int)), score, SLOT(display(int)));

    connect(game,SIGNAL(gameOver()),this,SLOT(gameOver()));
    connect(game,SIGNAL(winner()),this,SLOT(congrats()));
    game->notify();
}

void View::gameOver(){
    QMessageBox over;
    over.setText("You Lost !");
    over.setStandardButtons(QMessageBox::Ok);
    over.setStyleSheet("QLabel{min-width:500 px; font-size: 24px;font: bold} QPushButton{ width:250px; font-size: 18px; }");
    if (over.exec() == QMessageBox::Ok){
        QApplication::quit();
    }
}

void View::congrats(){
    QMessageBox msg;
    if(highScore > board->getScore()){
        writeToFile(board->getScore());
        msg.setText("Congratulations , You Won ! And You just hit the high score");
    }else{
        msg.setText("Congratulations , You Won !");
    }
    msg.setStandardButtons(QMessageBox::Retry | QMessageBox::Ok);
    msg.setStyleSheet("QLabel{min-width:500 px; font-size: 24px;font: bold} QPushButton{ width:250px; font-size: 18px; }");
    if (msg.exec() == QMessageBox::Ok){
        QApplication::quit();
    }else{
        initAll();
    }
}

View::~View() {
}

void View::refresh() {
    repaint();
    game->update();
}

void View::paintEvent(QPaintEvent*) {
    for(int x=0 ; x < heightView; ++x){
        for(int y=0; y < widthView; ++y){
            table->setItem(x,y,new QTableWidgetItem(board->getCellColor(x,y)));
            drawCell(x,y,board->getCellColor(x,y));
        }
    }
}

void View::cellSelected(int x, int y){
    game->floodFill(board->getCellColor(x,y));
}

void View::drawCell( int x, int y, int type) {
    static const std::vector< QColor > COLOR_TABLE = {
        Qt::white,
        Qt::darkRed,
        Qt::darkGreen,
        Qt::red,
        Qt::darkCyan,
        Qt::darkMagenta,
        Qt::blue,
        Qt::yellow
    };
    if( type <= 0 || (int)COLOR_TABLE.size() < type ) {
        return;
    }
    table->item(x,y)->setBackground(COLOR_TABLE[type-1]);
}

void View::readFile(){
    QString chaine;
    QFile myfile("score.txt");
    if (myfile.open(QFile::ReadOnly)){
        QTextStream out(&myfile);
        while(!out.atEnd()){
            chaine=out.readLine();
            QStringList filelist;
            QRegExp rx(";");
            filelist = chaine.split(rx);
            std::vector<int> v;
            for (int i = 0; i < filelist.size(); ++i){
                for(int j=0;j<4;++j){
                    v.push_back(filelist.at(j).split(";")[0].toInt());
                }
                if(v[0]==heightView && v[1]==widthView && v[2]==numberColors){
                    highScore=v[3];
                    break;
                }
            }
        }
        hScore->display(QString::number(highScore));
        myfile.close();
    }else{
        return;
    }
}

void View::writeToFile(int highScore){
    QFile file("score.txt");
    if(file.open(QIODevice::ReadWrite | QIODevice::Text))
    {
        QString string;
        QTextStream tstream(&file);
        QString line;
        while(!tstream.atEnd())
        {
            line = tstream.readLine();
            if(!line.contains(QString::number(heightView)+";"+QString::number(widthView)+";"+QString::number(numberColors)+";")){
                string.append(line + "\n");
            }
        }
        string.append(QString::number(heightView)+";"+QString::number(widthView)+";"+QString::number(numberColors)+";"+QString::number(highScore)+";");
        file.resize(0);
        tstream << string;
        file.close();
    }
}
