var searchData=
[
  ['data',['data',['../structqt__meta__stringdata___game__t.html#ab54431248d9d0aefbd4f85f8aab6e9d5',1,'qt_meta_stringdata_Game_t::data()'],['../structqt__meta__stringdata___view__t.html#a69efefc83dae2ca5a970b8eb15eb9f4e',1,'qt_meta_stringdata_View_t::data()']]]
];
