var searchData=
[
  ['_7eview',['~View',['../class_view.html#ad0dc854db9aabbea98a334dec89f785c',1,'View']]]
];
