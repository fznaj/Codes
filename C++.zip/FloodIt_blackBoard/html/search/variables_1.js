var searchData=
[
  ['stringdata0',['stringdata0',['../structqt__meta__stringdata___game__t.html#a34912798ec12a6fb51e6b4fb3e4c68e3',1,'qt_meta_stringdata_Game_t::stringdata0()'],['../structqt__meta__stringdata___view__t.html#abbde1a2fb6a2e274008881821124a792',1,'qt_meta_stringdata_View_t::stringdata0()']]]
];
