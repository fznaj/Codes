var searchData=
[
  ['scorechanged',['scoreChanged',['../class_game.html#ae65fe02995702636a67b17316f9e051a',1,'Game']]],
  ['setcellcolor',['setCellColor',['../class_board.html#af462d257272230653651f8e571c3c288',1,'Board']]],
  ['setcolor',['setColor',['../class_cell.html#ac68cafb57d586d5cbb0c7217435a3d4b',1,'Cell']]],
  ['setscore',['setScore',['../class_board.html#a83544661a73b85fee61c7ff578c0a05d',1,'Board']]],
  ['started',['started',['../class_game.html#a8940adf4094a3e95cd8b188af8d4d377',1,'Game']]]
];
