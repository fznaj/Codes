var searchData=
[
  ['addobserver',['addObserver',['../class_game.html#aa4519d2f0b848be2d8fa4de90e55792f',1,'Game']]]
];
