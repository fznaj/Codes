var searchData=
[
  ['qt_5fmeta_5fstringdata_5fgame_5ft',['qt_meta_stringdata_Game_t',['../structqt__meta__stringdata___game__t.html',1,'']]],
  ['qt_5fmeta_5fstringdata_5fview_5ft',['qt_meta_stringdata_View_t',['../structqt__meta__stringdata___view__t.html',1,'']]]
];
