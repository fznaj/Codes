var searchData=
[
  ['observer',['Observer',['../class_observer.html',1,'']]]
];
