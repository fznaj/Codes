var searchData=
[
  ['notify',['notify',['../class_game.html#a4eff13da36e6505f8196c83237e527b0',1,'Game']]]
];
