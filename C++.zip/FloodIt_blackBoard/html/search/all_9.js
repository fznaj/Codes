var searchData=
[
  ['observer',['Observer',['../class_observer.html',1,'']]],
  ['onnewgame',['onNewGame',['../class_view.html#a2453a04fe1e5100849e4dcda4a4e36da',1,'View']]]
];
