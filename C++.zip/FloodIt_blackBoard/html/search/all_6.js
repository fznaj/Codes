var searchData=
[
  ['game',['Game',['../class_game.html',1,'Game'],['../class_game.html#a3157f559fc8a1bc3ee031d86f7b1fed3',1,'Game::Game()']]],
  ['gameover',['gameOver',['../class_game.html#ac7d371f3f30513a4f3c57f521fac9b5f',1,'Game::gameOver()'],['../class_view.html#a8c643bb0e325fed4daa4e8d693725f74',1,'View::gameOver()']]],
  ['getcellcolor',['getCellColor',['../class_board.html#a824af651d1e7d1363e077fed27dd9793',1,'Board']]],
  ['getcolor',['getColor',['../class_cell.html#a44c337a43a41c7e08dd3af9668a85c4a',1,'Cell']]],
  ['getheight',['getHeight',['../class_board.html#a888725ae3b1177a60a8f77299c1c939a',1,'Board']]],
  ['getminsteps',['getMinSteps',['../class_board.html#a2d18791e1fcbade446ab21c69ecda689',1,'Board']]],
  ['getnbcolors',['getNbColors',['../class_board.html#a2b0ee5456157203e019aa6c043da65f1',1,'Board']]],
  ['getscore',['getScore',['../class_board.html#a9021b0f98de637a07cc6c1a73279b54b',1,'Board']]],
  ['getwidth',['getWidth',['../class_board.html#a31bdad2985e3b4857a383dd2da8e8e27',1,'Board']]],
  ['getx',['getX',['../class_cell.html#a40caf41e5ab28c67e0e8c547eb5281ee',1,'Cell']]],
  ['gety',['getY',['../class_cell.html#a0dc1e0edf77cb2c49840928025ef7360',1,'Cell']]]
];
