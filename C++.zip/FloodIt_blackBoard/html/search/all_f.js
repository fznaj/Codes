var searchData=
[
  ['view',['View',['../class_view.html',1,'View'],['../class_view.html#a74d64dd513eae96bc3196131f865a4e8',1,'View::View()']]]
];
