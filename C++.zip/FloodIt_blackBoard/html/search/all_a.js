var searchData=
[
  ['paintevent',['paintEvent',['../class_view.html#a48effcea1be64e57bc671ccb1e1ece75',1,'View']]],
  ['params',['params',['../class_view.html#a675d759c41b29f1e6bdc1a17c13cc4b6',1,'View']]]
];
