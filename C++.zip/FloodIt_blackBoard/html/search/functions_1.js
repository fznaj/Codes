var searchData=
[
  ['board',['Board',['../class_board.html#a806ff2c4f33b6615d028a8597afc02bd',1,'Board']]]
];
