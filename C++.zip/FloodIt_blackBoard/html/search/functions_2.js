var searchData=
[
  ['calculatenbsteps',['calculateNbSteps',['../class_board.html#afe8b4e1814759286117aa7d7c3b4c6e2',1,'Board']]],
  ['cell',['Cell',['../class_cell.html#a394510643e8664cf12b5efaf5cb99f71',1,'Cell::Cell()'],['../class_cell.html#a62418747cb6d940b2210767f459dc7fb',1,'Cell::Cell(int x, int y, int color)']]],
  ['cellselected',['cellSelected',['../class_view.html#aa6eb7ebbae6d726365dac9529d77465b',1,'View']]],
  ['checkgameover',['checkGameOver',['../class_board.html#a745f71da5ae55b6e91d18d232f941324',1,'Board']]],
  ['congrats',['congrats',['../class_view.html#aac2098bd7c212e04933df46840cc4ece',1,'View']]]
];
