var searchData=
[
  ['winner',['winner',['../class_game.html#a6c9cefc77ed4b8e7e7faf3ce4acc4b2d',1,'Game']]],
  ['writetofile',['writeToFile',['../class_view.html#a9a44377e4bfcbae5e49ad62da731b119',1,'View']]]
];
