var searchData=
[
  ['readfile',['readFile',['../class_view.html#abc4bfc7e1ab300f272f3b855fa899fc3',1,'View']]],
  ['refresh',['refresh',['../class_observer.html#abe6824f7ea1ee45757bf21f7a792bed8',1,'Observer::refresh()'],['../class_view.html#a0f4dbab1a758c980b0de90604ea0f9c8',1,'View::refresh()']]],
  ['removeobserver',['removeObserver',['../class_game.html#a1c54fe856d486b51cdebddd830c7b361',1,'Game']]]
];
