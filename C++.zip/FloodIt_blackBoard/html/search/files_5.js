var searchData=
[
  ['view_2ecpp',['view.cpp',['../view_8cpp.html',1,'']]],
  ['view_2eh',['view.h',['../view_8h.html',1,'']]]
];
