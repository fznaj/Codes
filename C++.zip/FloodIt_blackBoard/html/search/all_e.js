var searchData=
[
  ['update',['update',['../class_game.html#a79df6376b332d63c9eca0dcee30305c3',1,'Game']]],
  ['updatescore',['updateScore',['../class_game.html#a7e712ad06f0e6d8082e271d0427dcf42',1,'Game']]]
];
