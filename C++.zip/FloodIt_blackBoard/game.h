#ifndef GAME_H
#define GAME_H

#include <QWidget>

class Board;
class View;
class Observer;

/**
 * @brief The Game class represents the logic of the game
 */
class Game : public QWidget {
    Q_OBJECT

    /**
     * @brief board a pointer of Board
     */
    Board* board;

    /**
     * @brief view a pointer of View
     */
    View* view;

    /**
     * @brief observers a list of Observer
     */
    std::vector<Observer*> observers;

public:

    /**
     * @brief Game Constructor with parameters
     * @param board a pointer of a Board
     * @param view a pointer of a View
     * @param parent QWidget
     */
    Game( Board* board, View* view, QWidget* parent = 0 );

    /**
     * @brief addObserver adds an observer to the list
     * @param obs an Observer
     */
    void addObserver(Observer *obs);

    /**
     * @brief removeObserver removes an observer from the list
     * @param obs an Observer
     */
    void removeObserver(Observer &obs);

    /**
     * @brief notify notifies all the observers of the list
     */
    void notify();

    /**
     * @brief update emits scoreChanged and started signal and
     * checks for the end of the game
     */
    void update();

    /**
     * @brief updateScore updates the score
     */
    void updateScore();

public slots:

    /**
     * @brief floodFill floodFills with the new color id
     * @param id the new color
     */
    void floodFill(int id);

    /**
     * @brief initGame initializes the game
     */
    void initGame();

    /**
     * @brief endOfGameCheck checks for the end of the game :
     *  the player is either a winner or a loser. If he loses
     *  then the round is over and he can't play anymore
     */
    void endOfGameCheck();

signals:

    /**
     * @brief scoreChanged signal that's emitted whenever the score is changed
     * @param score the new score to be displayed
     */
    void scoreChanged(int score);

    /**
     * @brief gameOver is emitted when the game is over
     */
    void gameOver();

    /**
     * @brief winner is emmitted when the player wins
     */
    void winner();

    /**
     * @brief started emitted when the game is started to display the minimum number of steps
     * @param nbMinSteps the minimum number of steps
     */
    void started(int nbMinSteps);
};

#endif
