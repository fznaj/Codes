#include "board.h"
#include "cell.h"
#include "algorithm"
#include <tuple>

Board::Board(int boardHeight, int boardWidth, int nbInitColors) :
    height( boardHeight ), width ( boardWidth ), nbColors(nbInitColors){
    if( boardHeight <= 0 || boardWidth <= 0 ) {
        throw std::invalid_argument( "Width and length of the grid must be > 0" );
    }
}

void Board::initGrid(){
    init();
    calculateNbSteps();
    grid.clear();
    grid.resize(getHeight());
    for(std::vector<std::tuple< Cell,bool,bool >>& row : grid) {
        row.resize(getWidth());
    }
    for(int i = 0; i != getHeight(); ++i){
        for(int j = 0; j != getWidth(); ++j){
            grid[i][j] = std::make_tuple(*new Cell(i,j,rand() % nbColors +1),false,false);
        }
    }
    std::get<2>(grid[0][0]) = true;
}

void Board::init(){
    winner=false;
    gameover=false;
    nbSteps = 0;
    minNbSteps=0;
}

int Board::getHeight() const{
    return height;
}

int Board::getWidth() const{
    return width;
}

int Board::getNbColors() const{
    return nbColors;
}

int Board::getScore() {
    return nbSteps;
}

void Board::setScore(int newScore){
    nbSteps = newScore;
}

void Board::calculateNbSteps(){
    minNbSteps = width+height+nbColors;
}

int Board::getMinSteps(){
    return minNbSteps;
}

bool Board::isWinner(){
    return winner;
}

bool Board::isGameOver(){
    return gameover;
}

void Board::checkGameOver(){
    if(nbSteps>minNbSteps){
        gameover=true;
        return;
    }
    int type=getCellColor(0,0);
    for(int i = 0; i != getHeight(); ++i){
        for(int j = 0; j != getWidth(); ++j){
            if(getCellColor(i,j)!=type){
                return;
            }
        }
    }
    if(nbSteps > 0 && nbSteps <= minNbSteps){
        winner=true;
    }
}


int Board::getCellColor( int x, int y ) {
    if(x>=0 && x < getHeight() && y >=0 && y < getWidth()){
        return std::get<0>(grid[x][y]).getColor();
    }
    return -1;
}

void Board::setCellColor(int x, int y, int type){
    if(type <= -1){
        return;
    }
    std::get<0>(grid[x][y]).setColor(type);
}

void Board::floodFill(int x,int y, int id){
    std::get<1>(grid[x][y]) = true;
    if(std::get<2>(grid[x][y])){
        setCellColor(x, y, id);
    }
    if(getCellColor(x,y)==id){
        setCellColor(x,y,id);
        std::get<2>(grid[x][y]) = true;
    }else{
        return;
    }
    if(x+1>=1 && x+1 < getHeight() && y >=0 && y < getWidth()){
        Cell south = std::get<0>(grid[x+1][y]);
        if(south.getX() < getHeight() && !std::get<1>(grid[x+1][y])){
            floodFill(south.getX(), south.getY(), id);
        }
    }
    if(x-1>=1 && y >=0 && y < getWidth()){
        Cell north =std::get<0>(grid[x-1][y]);
        if(north.getX() >= 0 && !std::get<1>(grid[x-1][y])){
            floodFill(north.getX(), north.getY(), id);
        }
    }
    if(y+1>=1 && y+1 < getWidth() && x >=0 && x < getHeight()){
        Cell east = std::get<0>(grid[x][y+1]);
        if(east.getY() < getWidth() && !std::get<1>(grid[x][y+1])){
            floodFill(east.getX(), east.getY(), id);
        }
    }
    if(y-1>=1 && x >=0 && x < getHeight()){
        Cell west = std::get<0>(grid[x][y - 1]);
        if(west.getY() >= 0 && !std::get<1>(grid[x][y - 1])){
            floodFill(west.getX(), west.getY(), id);
        }
    }

}

void Board::initVisited(){
    for(int i = 0; i != getHeight(); ++i){
        for(int j = 0; j != getWidth(); ++j){
            std::get<1>(grid[i][j])=false;
        }
    }
}
