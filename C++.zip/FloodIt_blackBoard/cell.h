#ifndef CELL_H
#define CELL_H

/**
 * @brief The Cell class a cell in the grid
 */
class Cell
{

    /**
     * @brief x : the abscissa
     */
    int x;

    /**
     * @brief y : the ordinate
     */
    int y;

    /**
     * @brief color : the color of the cell
     */
    int color;

public:
    /**
     * @brief Cell constructor with no parameters
     */
    Cell();

    /**
     * @brief Cell constructor with parameters
     * @param x the abscissa
     * @param y the ordinate
     * @param color the color
     */
    Cell(int x, int y, int color);

    /**
     * @brief getX getter of the abscissa of the cell
     * @return  an integer representing the abscissa of the cell
     */
    int getX()const;

    /**
     * @brief getY getter of the ordinate of the cell
     * @return  an integer representing the ordinate of the cell
     */
    int getY()const;

    /**
     * @brief getColor getter of the color of the cell
     * @return an integer representing the color of the cell
     */
    int getColor()const;

    /**
     * @brief setColor sets a new color to the cell
     * @param newColor the new color to set
     */
    void setColor(int newColor);
};

#endif // CELL_H
