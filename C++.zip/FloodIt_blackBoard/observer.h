#ifndef OBSERVER_H
#define OBSERVER_H

/**
 * @brief The Observer class updates the view
 */
class Observer{

public:
    /**
     * @brief refresh pure virtual method that
     * updates the view
     */
    virtual void refresh()=0;
};

#endif // OBSERVER_H
