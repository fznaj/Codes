#include "game.h"
#include "board.h"
#include "view.h"
#include "observer.h"

#include <QWidget>
#include <QTextStream>

Game::Game(Board* board , View* view, QWidget* parent) :
    QWidget(parent ), board(board), view(view) {
}

void Game::addObserver(Observer *obs){
    observers.push_back(obs);
}

void Game::removeObserver(Observer &obs){
    observers.erase(std::remove(std::begin(observers), std::end(observers), &obs), std::end(observers));
}

void Game::notify(){
    for(auto &obs : observers){
        obs->refresh();
    }
}

void Game::update(){
    emit scoreChanged(board->getScore());
    emit started(board->getMinSteps());
    endOfGameCheck();
}

void Game::initGame() {
    board->initGrid();
    endOfGameCheck();
    notify();
}

void Game::endOfGameCheck(){
    board->checkGameOver();
    if(board->isWinner()){
        emit winner();
    }else if(board->isGameOver()){
        emit gameOver();
    }
}

void Game::updateScore(){
    board->setScore(board->getScore()+1);
}

void Game::floodFill(int id){
    board->initVisited();
    board->floodFill(0,0,id);
    updateScore();
    notify();
}
