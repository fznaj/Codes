#include "boss.h"

Boss::Boss(int id,const QPixmap &pixmap, int x, int y, int points) : Enemy(id, pixmap,x,y, points)
{
}
