#include "kamikaze.h"

Kamikaze::Kamikaze(int id,const QPixmap &pixmap,int x, int y, int points) : Enemy(id, pixmap,x,y,points)
{
}
