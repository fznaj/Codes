#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QTimer>

#include "bullet.h"

/**
 * @brief The Enemy class the mother class of the enemies.
 */
class Enemy : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:

    /**
     * @brief Enemy Constructor
     * @param id the enemy's id
     * @param pixmap the enemy's pixmap
     * @param x the abscissa of the enemy's position on the scene
     * @param y the oordinate of the enemy's position on the scene
     * @param points the number of points that are added to the ship's score
     * when the enemy is hit by the ship's bullet
     * @param parent
     */
    Enemy(int id,const QPixmap &pixmap,int x, int y, int points, QGraphicsItem *parent=0);

    /**
     * @brief swarmRight moves the enemy to the right
     * the position of the enemy is changed by adding 10 to the
     * position's abscissa
     */
    void swarmRight();

    /**
     * @brief swarmLeft moves the enemy to the left
     * the position of the enemy is changed by substracting 10 from
     * the position's abscissa
     */
    void swarmLeft();

    /**
     * @brief getPoints returns the enemy's points
     * @return integer representing the points
     */
    int getPoints();

    /**
     * @brief getId returns the enemy's id
     * @return an integer
     */
    int getId();

    /**
     * @brief inLeftEdge checks if the enemy is out of the scene from
     * the left
     * @return true if enemy's in edge, false otherwise
     */
    bool inLeftEdge();

    /**
     * @brief inRightEdge checks if the enemy is out of the scene from
     * the the right
     * @return true if enemy's in edge, false otherwise
     */
    bool inRightEdge();
public slots:

    /**
     * @brief attack throws bullets towards the ship
     */
    void attack();

    /**
     * @brief emitSignalForView emits a signal with the id of the
     * ship that was hit
     * @param id the ship's id
     */
    void emitSignalForView(int id);

    /**
     * @brief monsterAttack the monster fires the ship
     */
    void monsterAttack();
signals:

    /**
     * @brief bulletHitShip signal emitted when the ship is hit by
     * a bullet
     */
    void bulletHitShip(int);
private:

    /**
     * @brief id the enemy's id
     */
    int id;

    /**
     * @brief points the enemy's points
     */
    int points;

    /**
     * @brief timer used to attack the ship
     */
    QTimer *timer;

    /**
     * @brief bullet bullet
     */
    Bullet *bullet;
};

#endif // ENEMY_H
