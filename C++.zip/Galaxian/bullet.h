#ifndef BULLET_H
#define BULLET_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QGraphicsItem>

/**
 * @brief The Bullet class represents a bullet that is used
 * by both the ship and the enemies
 */
class Bullet : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
    /**
     * @brief hide removes the bullet from the scene and hides
     * the enemy at the position i of the list
     * @param collisionsList the list of the bullet's colliding items
     * @param i the position of the enemy hit by the bullet
     */
    void hide(QList<QGraphicsItem *> collisionsList, int i);

public:

    /**
     * @brief Bullet Constructor of Bullet
     * @param parent
     */
    Bullet(QGraphicsItem *parent=0);

public slots:

    /**
     * @brief move moves the bullet up towards the enemies
     */
    void move();

    /**
     * @brief fireShip moves the bullet down to fire
     * the ship
     */
    void fireShip();
signals:

    /**
     * @brief enemyFired this signal is emitted once an enemy is
     * touched by the bullet
     * @param enemy the id of the enemy
     * @param item the enemy
     * @param points enemy's points
     */
    void enemyFired(int enemy,QGraphicsItem * item, int points);

    /**
     * @brief shipFired signal emitted when the ship is fired by
     * an enemy
     * @param id the ship's id
     */
    void shipFired(int id);
};

#endif // BULLET_H
