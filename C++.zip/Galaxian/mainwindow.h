#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QRadioButton>

#include "dbmanagement.h"

/**
 * @brief The MainWindow class represents the window that allows
 * the player(s) to register
 */
class MainWindow: public QMainWindow {
    Q_OBJECT

    QVBoxLayout *layout;
    QLabel *txt;
    QLabel *scoreLbl;
    QTableWidget * scoreTable;
    QGroupBox *nbPlayers;
    QRadioButton *onePlayer;
    QRadioButton *twoPlayers;
    QPushButton *play;

    QTableWidgetItem *boss;
    QTableWidgetItem *alien;
    QTableWidgetItem *invader;
    QTableWidgetItem *kamikaze;

    dbManagement *db;

public:

    /**
     * @brief MainWindow Constrcutor
     * initializes the labels and the table and sets
     * the buttons and initializes the the database
     */
    explicit MainWindow();

    /**
     * @brief setGrid sets the grid of the scores and
     * the enemies images
     * @param img the enemy's image
     * @param name the file name
     * @param item each item representing a table item
     * @param x position in the table
     * @param y position in the table
     * @param tab the table
     * @param convoy the enemy's convoy
     * @param charger the enemy's points
     * @param font the font used
     */
    void setGrid(QImage *img, QString name, QTableWidgetItem *item,
                 int x, int y, QTableWidget *tab,QString convoy, QString charger,QFont font);

    /**
     * @brief setLabel sets label
     * @param label the label to set
     * @param font the font used
     * @param color the color used
     */
    void setLabel(QLabel *label,QFont font,QString color);


public slots:

    /**
     * @brief start starts the game
     * @param p1 first player's name
     * @param p2 second player's name
     */
    void start(QString p1, QString p2);

    /**
     * @brief playerOptions allows the players to register with their names
     */
    void playerOptions();
};

#endif // MAINWINDOW_H
