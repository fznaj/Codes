#include "monster.h"

Monster::Monster(int id,const QPixmap &pixmap, int x, int y, int points) : Enemy(id, pixmap,x,y, points)
{

}
