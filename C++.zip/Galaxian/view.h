#ifndef VIEW_H
#define VIEW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QTimer>
#include <vector>
#include <QSqlQuery>
#include <QSplashScreen>

#include "ship.h"
#include "enemy.h"
#include "monster.h"
#include "dbmanagement.h"

namespace Ui{
class View;
}

/**
 * @brief The View class the view of the game is represented by this class
 */
class View : public QMainWindow
{
    Q_OBJECT

public:

    /**
     * @brief View Constructor
     * @param db the database
     * @param p1 the first player's name
     * @param p2 the second player's name, empty if only 1 player
     * @param parent
     */
    explicit View(dbManagement *db,QString p1,QString p2,QWidget *parent = 0);

    void keyPressEvent( QKeyEvent* e );

    /**
     * @brief MAX_LEVEL defines the maximum level of the game
     */
    static const int MAX_LEVEL = 5;

    /**
     * @brief MAIN_TIMER defines de minimum amount of
     * the timer used by the enemies to swarm
     */
    static const int MAIN_TIMER = 1000;

    static const int ATTACK_TIMER = 10000;

    ~View();

private:

    Ui::View *ui;

    int level;
    QGraphicsScene *scene;
    QTimer *timer;
    QTimer *enemiesTimer;
    QTimer *beastTimer;

    dbManagement *db;

    QString playerName[2];
    Ship *playerShip[2];
    QGraphicsTextItem *score[2];
    QGraphicsPixmapItem *life1[3];
    QGraphicsPixmapItem *life2[3];

    std::vector<Enemy*> boss;
    std::vector<Enemy*> alien;
    std::vector<Enemy*> invader;
    std::vector<Enemy*> kamikaze;

    Monster *beast;
    int cptBeastHit;

    QGraphicsTextItem *levelBreakText;

    /**
     * @brief checkInEdge checks if one of the enemies vector has reached
     * the edge of the scene from both sides.
     * @return true if in edge, false otherwise
     */
    bool checkInEdge();

    /**
     * @brief checkKamikazeEdge checks if one of the kamikaze vector elements has reached
     * the edge of the scene from both sides.
     * @return true if in edge, false otherwise
     */
    bool checkKamikazeEdge();

    /**
     * @brief enemyContained finds the enemy 'e' in the vector 'enemy'
     * and erases it
     * @param enemy the enemy's vector
     * @param e the enemy
     * @return the new vector modified
     */
    std::vector<Enemy *> enemyContained(std::vector<Enemy*> enemy,QGraphicsItem* e);

    /**
     * @brief playersInit initializes the players, their lives and scores
     */
    void playersInit();

    /**
     * @brief enemiesKilled checks if all the vectors are empty
     * @return true if killed, false otherwise
     */
    bool enemiesKilled();

    /**
     * @brief setWinner sets the winner
     * @param id the ship'id of the winner
     */
    void setWinner(int id);

    /**
     * @brief nextLevel if all enemies of the level are killed
     * goes to the next level
     */
    void nextLevel();

    /**
     * @brief setEnemy sets all the enemies
     */
    void setEnemy();

    /**
     * @brief gameOver game over message
     */
    void gameOver();

    /**
     * @brief lastLevel the level of the last enemies' type
     */
    void lastLevel();

public slots:

    /**
     * @brief displayScore update the database and sets the scores
     * @param newScore the new score
     * @param id the ship's id
     */
    void displayScore(int newScore,int id);

    /**
     * @brief eliminateEnemy deletes enemy from its vector
     * @param type enemy's type
     * @param enemy the enemy
     */
    void eliminateEnemy(int type, QGraphicsItem* enemy);

    /**
     * @brief setLife sets the ship's life
     * @param newLife the new life to set
     * @param px the pixmap
     * @param iFirst first index of the life's vector
     * @param iLast last index of the life's vector
     * @param life the vector of lives
     */
    void setLife(int newLife, const QPixmap px, int iFirst, int iLast, QGraphicsPixmapItem *life[]);

    /**
     * @brief swarm swarms the enemies
     */
    void swarm();

    /**
     * @brief updateShip updates the ship if it still got at least 1 life
     * otherwise it's gameover or if there are 2 players then it sets the
     * winner
     * @param id the ship's id
     */
    void updateShip(int id);

    /**
     * @brief attack the enemies attack the ship
     */
    void attack();

    /**
     * @brief showShip shows the ship when hidden
     */
    void showShip();

    /**
     * @brief levelBreak break between the levels
     * resets the enemies and the ships life and the timer
     */
    void levelBreak();
};

#endif // MAINWINDOW_H
