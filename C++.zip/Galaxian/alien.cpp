#include "alien.h"

Alien::Alien(int id,const QPixmap &pixmap, int x, int y, int points) :Enemy(id, pixmap,x,y, points)
{
}
