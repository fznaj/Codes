#ifndef BOSS_H
#define BOSS_H

#include "enemy.h"

/**
 * @brief The Boss class the this class represents the type 1 of the enemies
 */
class Boss : public Enemy
{
public:

    /**
     * @brief Boss Constructor
     * @param id the boss id
     * @param pixmap the pixmap that represents the alien
     * @param x the abscissa of the boss' position on the scene
     * @param y the oordinate of the boss' position on the scene
     * @param points the number of points that are added to the ship's score
     * when the boss is hit by the ship's bullet
     */
    Boss(int id,const QPixmap &pixmap,int x, int y, int points);
};

#endif // BOSS_H
