#include <QGraphicsView>
#include <QGraphicsTextItem>
#include <algorithm>
#include <QMovie>
#include <QLabel>
#include <QGraphicsProxyWidget>
#include <QMessageBox>
#include <QSqlQuery>

#include "view.h"
#include "ui_view.h"
#include "boss.h"
#include "alien.h"
#include "invader.h"
#include "kamikaze.h"

View::View(dbManagement *db,const QString p1, const QString p2, QWidget *parent):QMainWindow(parent),ui(new Ui::View){
    playerName[0] = p1;
    playerName[1] = p2;

    this->db = db;

    ui->setupUi(this);
    scene = new QGraphicsScene(this);
    scene->setSceneRect(0,0,800,480);

    QMovie *movie = new QMovie("images/bg.gif");
    movie->setScaledSize(QSize(800,480));
    QLabel *movieLabel;
    movieLabel = new QLabel(0);
    movieLabel->setMovie(movie);
    movie->start();
    scene->addWidget(movieLabel);

    ui->graphicsView->setBackgroundBrush(QPixmap("bg.gif"));
    ui->graphicsView->setWindowTitle(tr("Galaxian"));
    ui->graphicsView->setFixedSize(800,480);
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    level = 1;
    cptBeastHit = 0;

    setEnemy();
    playersInit();

    timer = new QTimer(this);
    timer->start(MAIN_TIMER);
    enemiesTimer = new QTimer(this);
    enemiesTimer->start(ATTACK_TIMER);
    connect(timer,SIGNAL(timeout()),this,SLOT(swarm()));
    connect(enemiesTimer,SIGNAL(timeout()),this,SLOT(attack()));
}

void View::setEnemy(){
    QPixmap pxBoss("images/boss.png");
    for(int i=427,j=0;i<600 && j<4;i+=50,j++){
        boss.push_back(new Boss(1,pxBoss,i,50,300));
        connect(boss[j],SIGNAL(bulletHitShip(int)),this,SLOT(updateShip(int)));
        scene->addItem(boss[j]);
    }

    QPixmap pxAlien("images/alien.png");
    for(int i=379,j=0;i<700 && j<6;i+=50,j++){
        alien.push_back(new Alien(2, pxAlien,i,75,100));
        connect(alien[j],SIGNAL(bulletHitShip(int)),this,SLOT(updateShip(int)));
        scene->addItem(alien[j]);
    }

    QPixmap pxInvader("images/invader.png");
    for(int i=327,j=0;i<800 && j<8;i+=50,j++){
        invader.push_back(new Invader(3, pxInvader,i,100,80));
        connect(invader[j],SIGNAL(bulletHitShip(int)),this,SLOT(updateShip(int)));
        scene->addItem(invader[j]);
    }

    QPixmap pxKamikaze("images/kamikaze.png");

    int i=280,j=0,k=125;
    while(j<30 && k<175){
        while(i<750){
            kamikaze.push_back(new Kamikaze(4,pxKamikaze,i,k,50));
            connect(kamikaze[j],SIGNAL(bulletHitShip(int)),this,SLOT(updateShip(int)));
            scene->addItem(kamikaze[j]);
            if(j==9 || j==19 || j==29){
                k+=25;
                i=230;
            }
            i+=50;
            ++j;
        }
    }
}

void View::playersInit(){
    QPixmap pxShip("images/ship.png");
    if(!playerName[1].isEmpty()){
        playerShip[0] = new Ship(1,pxShip,340,350,3,0);
        playerShip[1] =new Ship(2,pxShip,400,350,3,0);
        scene->addItem(playerShip[1]);
        setLife(playerShip[1]->getLife(),pxShip,640,681,life2);

        score[1] = new QGraphicsTextItem();
        score[1]->setDefaultTextColor(Qt::red);
        score[1]->setFont(QFont("Courier 10 Pitch",16));
        score[1]->setPos(640,380);
        displayScore(playerShip[1]->getScore(),2);
        scene->addItem(score[1]);

        connect(playerShip[1],SIGNAL(scoreChanged(int,int)),this,SLOT(displayScore(int,int)));
        connect(playerShip[1],SIGNAL(enemyPos(int,QGraphicsItem *)),this,SLOT(eliminateEnemy(int,QGraphicsItem*)));
    }else{
        playerShip[0] = new Ship(1,pxShip,370,350,3,0);
    }
    connect(playerShip[0],SIGNAL(scoreChanged(int,int)),this,SLOT(displayScore(int,int)));
    connect(playerShip[0],SIGNAL(enemyPos(int,QGraphicsItem *)),this,SLOT(eliminateEnemy(int,QGraphicsItem*)));

    scene->addItem(playerShip[0]);
    setLife(playerShip[0]->getLife(),pxShip,0,41,life1);

    score[0] = new QGraphicsTextItem();
    score[0]->setDefaultTextColor(Qt::red);
    score[0]->setFont(QFont("Courier 10 Pitch",16));
    score[0]->setPos(0,380);
    displayScore(playerShip[0]->getScore(),1);
    scene->addItem(score[0]);
}

void View::nextLevel(){
    if(enemiesKilled()){
        level++;
        QFont font("Courier 10 Pitch",30,QFont::Bold, false);
        levelBreakText=new QGraphicsTextItem();
        levelBreakText->setPlainText("Level "+QString::number(level));
        levelBreakText->setFont(font);
        levelBreakText->setDefaultTextColor(Qt::red);
        levelBreakText->setPos(300, 200);
        levelBreakText->show();
        scene->addItem(levelBreakText);
        timer->stop();
        enemiesTimer->stop();
        QTimer *t = new QTimer;
        t->setSingleShot(true);
        connect(t, SIGNAL(timeout()), this, SLOT(levelBreak()));
        t->start(1000);
    }
}

void View::levelBreak(){
    QPixmap pxShip("images/ship.png");
    levelBreakText->hide();
    if(!playerName[1].isEmpty()){
        playerShip[0]->setPos(340,350);
        playerShip[1]->setPos(400,350);
        playerShip[1]->setLife(3);
        setLife(playerShip[1]->getLife(),pxShip,640,681,life2);
    }else{
        playerShip[0]->setPos(370,350);
    }
    playerShip[0]->setLife(3);
    setLife(playerShip[0]->getLife(),pxShip,0,41,life1);
    enemiesTimer->start(ATTACK_TIMER-600*level);
    if(level < MAX_LEVEL){
        setEnemy();
        timer->start(MAIN_TIMER-200*level);
    }else{
        timer->start(600);
        lastLevel();
    }
}

void View::lastLevel(){
    QPixmap beastPx("images/monster.png");
    beast = new Monster(10,beastPx,0,150,500);
    connect(beast,SIGNAL(bulletHitShip(int)),this,SLOT(updateShip(int)));
    scene->addItem(beast);
    beastTimer = new QTimer();
    connect(beastTimer,SIGNAL(timeout()),this,SLOT(attack()));
    connect(beastTimer,SIGNAL(timeout()),this,SLOT(swarm()));
    beastTimer->start(MAIN_TIMER);
}

void View::updateShip(int id){
    if(playerShip[id-1]->checkLife()){
        playerShip[id-1]->setLife(playerShip[id-1]->getLife()-1);
        if(id==1){
            life1[playerShip[id-1]->getLife()]->hide();
        }else{
            life2[playerShip[id-1]->getLife()]->hide();
        }
        playerShip[id-1]->hide();
        QTimer *t = new QTimer;
        t->setSingleShot(true);
        connect(t, SIGNAL(timeout()), this, SLOT(showShip()));
        t->start(500);
    }else{
        timer->stop();
        enemiesTimer->stop();
        if(id==2){
            setWinner(0);
        }else if(id==1 && playerName[1].isEmpty()){
            gameOver();
        }else{
            setWinner(1);
        }
    }
}

void View::showShip(){
    playerShip[0]->show();
    if(!playerName[1].isEmpty()){
        playerShip[1]->show();
    }
}

void View::setWinner(int id){
    QMessageBox msgBox;
    QFont font("Courier 10 Pitch",15,QFont::Bold, false);
    msgBox.setFont(font);
    msgBox.addButton(tr("Quit the game"), QMessageBox::NoRole);
    msgBox.setText("The winner is "+playerName[id]+"\nCongratulations!!");
    msgBox.exec();
    QApplication::quit();
}

void View::gameOver(){
    QMessageBox msgBox;
    QFont font("Courier 10 Pitch",15,QFont::Bold, false);
    msgBox.setFont(font);
    msgBox.addButton(tr("Quit the game"), QMessageBox::NoRole);
    msgBox.setText("You lost. Game Over!");
    msgBox.setMaximumSize(50,20);
    msgBox.exec();
    QApplication::quit();
}

bool View::enemiesKilled(){
    return playerShip[0]->getScore()>0 && (boss.size()==0 && alien.size()==0 && invader.size()==0
            && kamikaze.size()==0);
}

void View::setLife(int newLife, const QPixmap px, int iFirst, int iLast, QGraphicsPixmapItem *life[]){
    for(int i=iFirst,j=0;i<iLast && j<newLife;i+=20,j++){
        life[j]=new QGraphicsPixmapItem(px);
        life[j]->setPos(i,405);
        life[j]->setScale(0.3);
        scene->addItem(life[j]);
    }
}

void View::displayScore(int newScore, int id){
    db->updateScore(newScore,playerName[id-1]);
    score[id-1]->setPlainText(QString("Score ")+QString::number(newScore));
}

void View::swarm(){
    if(timer->isActive()){
        if(level < MAX_LEVEL){
            if(!checkInEdge()){
                for(unsigned int i=0;i<boss.size();++i){
                    boss[i]->swarmLeft();
                }
                for(unsigned int i=0;i<alien.size();++i){
                    alien[i]->swarmLeft();
                }
                for(unsigned int i=0;i<invader.size();++i){
                    invader[i]->swarmLeft();
                }
                for(unsigned int i=0;i<kamikaze.size();++i){
                    kamikaze[i]->swarmLeft();
                }
            }
        }else{
            if(!beast->inRightEdge()){
                beast->swarmRight();
            }
        }
    }
}

void View::attack(){
    int randomNb;
    if(timer->isActive() && enemiesTimer->isActive()){
        if(level<MAX_LEVEL){
            if(boss.size()>0){
                randomNb = rand()%boss.size();
                boss[randomNb]->attack();
            }
            if(alien.size()>0){
                randomNb = rand()%alien.size();
                alien[randomNb]->attack();
            }
            if(invader.size()>0){
                randomNb = rand()%invader.size();
                invader[randomNb]->attack();
            }
            if(kamikaze.size()>0){
                randomNb = rand()%kamikaze.size();
                kamikaze[randomNb]->attack();
            }
        }else{
            beast->monsterAttack();
        }
    }
}

bool View::checkInEdge(){
    return boss[0]->inLeftEdge() || alien[0]->inLeftEdge()
            || invader[0]->inLeftEdge() || checkKamikazeEdge();
}

bool View::checkKamikazeEdge(){
    for(unsigned int e=0;e<kamikaze.size();++e){
        return kamikaze[e]->inLeftEdge();
    }
    return false;
}

void View::eliminateEnemy(int type, QGraphicsItem *enemy){
    switch(type){
    case 1:
        boss = enemyContained(boss,enemy);
        break;
    case 2:
        alien = enemyContained(alien,enemy);
        break;
    case 3:
        invader = enemyContained(invader,enemy);
        break;
    case 4:
        kamikaze = enemyContained(kamikaze,enemy);
        break;
    case 5:
        cptBeastHit++;
        if(cptBeastHit == 10){
            enemy->hide();
            beastTimer->stop();
            if(!playerName[1].isEmpty() && playerShip[0]->getScore()<playerShip[1]->getScore()){
                setWinner(1);
            }else{
                setWinner(0);
            }
        }
        return;
    default:
        break;
    }
    nextLevel();
}

std::vector<Enemy*> View::enemyContained(std::vector<Enemy *> enemy, QGraphicsItem *e){
    enemy.erase(std::find(enemy.begin(), enemy.end(), e));
    return enemy;
}

void View::keyPressEvent(QKeyEvent *e){
    if(!playerName[1].isEmpty()){
        switch(e->key()){
        case Qt::Key_O:
            playerShip[1]->moveLeft();
            break;
        case Qt::Key_P:
            playerShip[1]->moveRight();
            break;
        case Qt::Key_AltGr:
            playerShip[1]->fire();
            break;
        default:
            QMainWindow::keyPressEvent(e);
            break;
        }
    }
    switch(e->key()){
    case Qt::Key_Z:
        playerShip[0]->moveRight();
        break;
    case Qt::Key_A:
        playerShip[0]->moveLeft();
        break;
    case Qt::Key_Alt:
        playerShip[0]->fire();
        break;
    default:
        QMainWindow::keyPressEvent(e);
        break;
    }
}

View::~View(){
    delete ui;
}
