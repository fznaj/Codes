#include <typeinfo>
#include <QGraphicsScene>
#include <QGraphicsItem>
#include <QList>
#include <QTimer>

#include "bullet.h"
#include "boss.h"
#include "alien.h"
#include "invader.h"
#include "kamikaze.h"
#include "monster.h"
#include "ship.h"

Bullet::Bullet(QGraphicsItem *parent) : QGraphicsPixmapItem(parent)
{
    setPixmap(QPixmap("images/fireball.png"));
    setScale(0.1);
}

void Bullet::hide(QList<QGraphicsItem *> collisionsList, int i)
{
    scene()->removeItem(this);
    collisionsList[i]->hide();
    delete this;
    return;
}

void Bullet::move(){
    QList<QGraphicsItem *> collisionsList = collidingItems();
    int  n = collisionsList.size();
    for (int i = 0; i < n; ++i){
        if(typeid(*(collisionsList[i]))==typeid(Boss)||
                (typeid(*(collisionsList[i]))==typeid(Alien)) ||
                (typeid(*(collisionsList[i]))==typeid(Invader)) ||
                (typeid(*(collisionsList[i]))==typeid(Kamikaze))){
            int points = qgraphicsitem_cast<Enemy*>(collisionsList[i])->getPoints();
            int id = qgraphicsitem_cast<Enemy*>(collisionsList[i])->getId();
            emit enemyFired(id,collisionsList[i],points);
            hide(collisionsList, i);
        }else if(typeid(*(collisionsList[i]))==typeid(Monster)){
            emit enemyFired(5,collisionsList[i],500);
            scene()->removeItem(this);
            delete this;
            return;
        }
    }

    setPos(x(),y()-10);
    if (pos().y() < 0){
        scene()->removeItem(this);
        delete this;
    }
}

void Bullet::fireShip(){
    QList<QGraphicsItem *> collisionsList = collidingItems();
    int  n = collisionsList.size();
    for (int i = 0; i < n; ++i){
        if (typeid(*(collisionsList[i])) == typeid(Ship)){
            int id = qgraphicsitem_cast<Ship*>(collisionsList[i])->getId();
            emit shipFired(id);
            hide(collisionsList, i);
        }
    }

    setPos(x(),y()+10);
    if (pos().y() > 400){
        scene()->removeItem(this);
        delete this;
    }
}
