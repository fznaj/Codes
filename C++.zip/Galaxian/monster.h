#ifndef MONSTER_H
#define MONSTER_H

#include "enemy.h"

/**
 * @brief The Monster class this class represents the type 5 of the enemies
 */
class Monster : public Enemy
{
public:

    /**
     * @brief Monster Constructor
     * @param id the monster's id
     * @param pixmap the pixmap that represents the monster
     * @param x the abscissa of the monster's position on the scene
     * @param y the oordinate of the monster's position on the scene
     * @param points the number of points that are added to the ship's score
     * when the monster is hit by the ship's bullet
     */
    Monster(int id,const QPixmap &pixmap,int x, int y, int points);
};

#endif // MONSTER_H
