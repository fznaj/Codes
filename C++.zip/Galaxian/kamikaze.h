#ifndef KAMIKAZE_H
#define KAMIKAZE_H

#include "enemy.h"

/**
 * @brief The Kamikaze class this class represents the type 4 of the enemies
 */
class Kamikaze : public Enemy
{
public:

    /**
     * @brief Kamikaze Constructor
     * @param id the kamikaze id
     * @param pixmap the pixmap that represents the kamikaze
     * @param x the abscissa of the kamikaze position on the scene
     * @param y the oordinate of the kamikaze position on the scene
     * @param points the number of points that are added to the ship's score
     * when the kamikaze is hit by the ship's bullet
     */
    Kamikaze(int id,const QPixmap &pixmap,int x, int y, int points);
};

#endif // KAMIKAZE_H
