#include <QGraphicsScene>

#include "ship.h"
#include "bullet.h"

Ship::Ship(int id, const QPixmap &pixmap, int x, int y, int life, int score, QGraphicsItem *parent) : QGraphicsPixmapItem(pixmap,parent)
{
    this->id = id;
    this->life = life;
    this->score=score;
    setPos(x,y);
    setScale(0.7);
}

int Ship::getId(){
    return id;
}

int Ship::getLife(){
    return life;
}

void Ship::setLife(int newLife){
    life = newLife;
}

int Ship::getScore(){
    return score;
}

void Ship::fire(){
    bullet = new Bullet();
    bullet->setRotation(90);
    timer = new QTimer(this);
    timer->start(80);
    connect(timer,SIGNAL(timeout()),bullet,SLOT(move()));
    connect(bullet,SIGNAL(enemyFired(int,QGraphicsItem *,int)),this,SLOT(setScore(int,QGraphicsItem*,int)));
    bullet->setPos(x()+38,y()-30);
    scene()->addItem(bullet);
}

bool Ship::checkLife(){
    return life > 0;
}

void Ship::moveRight(){
    if(x()< 750){
        setPos(x()+10,y());
    }
}

void Ship::moveLeft(){
    if(x()>0){
        setPos(x()-10,y());
    }
}

void Ship::setScore(int type, QGraphicsItem *item, int points){
    score+=points;
    emit scoreChanged(getScore(),getId());
    emit enemyPos(type,item);
}
