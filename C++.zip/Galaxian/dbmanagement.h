#ifndef DBMANAGEMENT_H
#define DBMANAGEMENT_H

#include <QSqlQuery>

/**
 * @brief The dbManagement class this class contains the methods
 * needed to create, add and update the tables.
 */
class dbManagement
{
public:

    /**
     * @brief dbManagement Constructor that initiates the database
     * by opening it and creates the necessary tables.
     */
    dbManagement();

    /**
     * @brief init sets the database name and opens it.
     */
    void init();

    /**
     * @brief create creates the table player
     */
    void create();

    /**
     * @brief addPlayer inserts a new player in the table
     * @param userName the username enetered by the player
     * @param score the initial score
     * @return returns true if the player was added correctly. False
     * otherwise.
     */
    bool addPlayer(const QString &userName, int score);

    /**
     * @brief updateScore updates the score of the specified player
     * @param newScore the new score
     * @param user the player concerned
     * @return returns true if the score was correctly updated. False
     * otherwise.
     */
    bool updateScore(int newScore, QString user);

    /**
     * @brief getHighScore returns the highest score of the scores in
     * the table
     * @return the score
     */
    QString getHighScore();
};

#endif // DBMANAGEMENT_H
