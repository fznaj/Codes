#include <QGraphicsScene>

#include "enemy.h"

Enemy::Enemy(int id,const QPixmap &pixmap, int x, int y, int points, QGraphicsItem *parent):QGraphicsPixmapItem(pixmap,parent)
  ,points(points){
    this->id = id;
    setPos(x,y);
    setScale(0.5);
    timer=new QTimer();
}

int Enemy::getId(){
    return id;
}

int Enemy::getPoints(){
    return points;
}

void Enemy::attack(){
    bullet = new Bullet();
    bullet->setRotation(-90);
    bullet->setPos(x()+10,y()+70);
    scene()->addItem(bullet);
    timer->start(100);
    connect(timer,SIGNAL(timeout()),bullet,SLOT(fireShip()));
    connect(bullet,SIGNAL(shipFired(int)),this,SLOT(emitSignalForView(int)));
}

void Enemy::monsterAttack(){
    bullet = new Bullet();
    bullet->setRotation(-90);
    bullet->setPos(x()+50,y()+150);
    scene()->addItem(bullet);
    timer->start(100);
    connect(timer,SIGNAL(timeout()),bullet,SLOT(fireShip()));
    connect(bullet,SIGNAL(shipFired(int)),this,SLOT(emitSignalForView(int)));
}

bool Enemy::inLeftEdge(){
    return x()<=15;
}

bool Enemy::inRightEdge(){
    return x()>=650;
}

void Enemy::swarmLeft(){
    setPos(x()-10,y());
}

void Enemy::swarmRight(){
    setPos(x()+10,y());
}

void Enemy::emitSignalForView(int id){
    emit bulletHitShip(id);
}
