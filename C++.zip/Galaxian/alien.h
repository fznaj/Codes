#ifndef ALIEN_H
#define ALIEN_H

#include "enemy.h"

/**
 * @brief The Alien class this class represents the type 2 of the enemies
 */
class Alien : public  Enemy
{
public:

    /**
     * @brief Alien Constructor
     * @param id the alien's id
     * @param pixmap the pixmap that represents the alien
     * @param x the abscissa of the alien's position on the scene
     * @param y the oordinate of the alien's position on the scene
     * @param points the number of points that are added to the ship's score
     * when the alien is hit by the ship's bullet
     */
    Alien(int id,const QPixmap &pixmap,int x, int y, int points);
};

#endif // ALIEN_H
