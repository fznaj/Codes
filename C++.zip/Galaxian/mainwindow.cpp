#include <QApplication>
#include <QString>
#include <QInputDialog>
#include <QMessageBox>
#include <QHeaderView>
#include <QRadioButton>

#include "mainwindow.h"
#include "view.h"

MainWindow::MainWindow()
{
    db = new dbManagement();

    QFont font("Courier 10 Pitch",15,QFont::Bold, false);

    txt= new QLabel("WE ARE THE GALAXIANS\nMISSION : DESTROY ALIENS\n");
    setLabel(txt,font,"color:red");

    QLabel *highScore = new QLabel("HIGH SCORE "+db->getHighScore());
    setLabel(highScore,font,"color:white");

    scoreLbl = new QLabel("-- SCORE ADVANCE TABLE --");
    setLabel(scoreLbl,font,"color:white");

    scoreTable = new QTableWidget;
    scoreTable->setColumnCount(4);
    scoreTable->setRowCount(5);
    scoreTable->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scoreTable->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scoreTable->horizontalHeader()->setVisible(false);
    scoreTable->verticalHeader()->setVisible(false);
    scoreTable->horizontalHeader()->setDefaultSectionSize(90);
    scoreTable->verticalHeader()->setDefaultSectionSize(40);

    QLabel *convoy = new QLabel("CONVOY");
    setLabel(convoy,font,"color:cyan");
    QLabel *charger = new QLabel("CHARGER");
    setLabel(charger,font,"color:cyan");
    scoreTable->setCellWidget(0,2,convoy);
    scoreTable->setCellWidget(0,3,charger);

    QImage *img = new QImage(1,1,QImage::Format_RGB32);
    setGrid(img,"images/boss.png",boss,1,1,scoreTable,"60","300",font);
    setGrid(img,"images/alien.png",alien,2,1,scoreTable,"50","100",font);
    setGrid(img,"images/invader.png",invader,3,1,scoreTable,"40","80",font);
    setGrid(img,"images/kamikaze.png",kamikaze,4,1,scoreTable,"30","60",font);

    nbPlayers = new QGroupBox(tr("Choose the number of players"));
    nbPlayers->setStyleSheet("color:gray");
    nbPlayers->setFont(font);
    onePlayer = new QRadioButton(tr("&1 player"));
    onePlayer->setChecked(true);
    twoPlayers = new QRadioButton(tr("&2 players"));

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addWidget(onePlayer);
    vbox->addWidget(twoPlayers);
    nbPlayers->setLayout(vbox);

    play = new QPushButton;
    QPixmap icon("images/play.png");
    play->setIcon(QIcon(icon));
    play->setIconSize(QSize(70,50));

    connect(play,SIGNAL(clicked()),this,SLOT(playerOptions()));
    layout = new QVBoxLayout;
    layout->addWidget(txt);
    layout->addWidget(highScore);
    layout->addWidget(scoreLbl);
    layout->addWidget(scoreTable);
    layout->addWidget(nbPlayers);
    layout->addWidget(play);

    QWidget *window = new QWidget;
    window->setLayout(layout);
    this->setCentralWidget(window);
    this->setWindowTitle("Galaxian");
    this->setStyleSheet("background-color:black;");
    this->setFixedSize(420,550);
}

void MainWindow::setGrid(QImage *img, QString name, QTableWidgetItem *item, int x, int y, QTableWidget *tab, QString convoy, QString charger, QFont font){
    img->load(name);
    item = new QTableWidgetItem;
    item->setData(Qt::DecorationRole, QPixmap(name).scaled(40, 40, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    tab->setItem(x, y, item);
    QLabel *lb1=new QLabel(convoy);
    setLabel(lb1,font,"color:cyan");
    tab->setCellWidget(x,y+1,lb1);
    QLabel *lb2=new QLabel(charger+" PTS");
    setLabel(lb2,font,"color:cyan");
    tab->setCellWidget(x,y+2,lb2);
}

void MainWindow::setLabel(QLabel *label, QFont font, QString color){
    label->setStyleSheet(color);
    label->setFont(font);
    label->setAlignment(Qt::AlignCenter);
}

void MainWindow::playerOptions(){
    bool ok,done;
    QString username1,username2;
    username1= QInputDialog::getText(0, "Welcome","Please enter the player's name : ",
                                     QLineEdit::Normal,"", &ok);
    if(twoPlayers->isChecked()){
        username2= QInputDialog::getText(0, "Welcome","Please enter the second player's name : ",
                                         QLineEdit::Normal,"", &done);
    }
    if(onePlayer->isChecked() && ok && !username1.isEmpty()){
        if (!db->addPlayer(username1,0)){
            QApplication::quit();
        }
        start(username1,"");
    }else if(twoPlayers->isChecked() && done && !username1.isEmpty() && !username2.isEmpty()){
        if (!db->addPlayer(username1,0) || !db->addPlayer(username2,0)){
            QApplication::quit();
        }
        start(username1,username2);
    }else if(!ok || !done){
        QApplication::quit();
    }else{
        QMessageBox::warning(0, "Warning",
                             QString("The username must be entered"));
        playerOptions();
    }
}

void MainWindow::start(QString p1,QString p2){
    View *v = new View(db,p1,p2,this);
    v->setFixedSize(800,480);
    v->show();
}
