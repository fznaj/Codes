var class_ui___view =
[
    [ "retranslateUi", "class_ui___view.html#a587c173f7ee63dc03d8754dd14324eb4", null ],
    [ "setupUi", "class_ui___view.html#a637ba7f9c4beb610375f91f117f05208", null ],
    [ "centralWidget", "class_ui___view.html#aaf692fbbca2d9f417c61bc102baa735e", null ],
    [ "graphicsView", "class_ui___view.html#a47bef1bf268937bf725696487ea64327", null ],
    [ "mainToolBar", "class_ui___view.html#ae1b6ed751a2aa7e05bfd27b1d0968e76", null ],
    [ "menuBar", "class_ui___view.html#a7e1b0b71aa63fed674f7b0cc0ee89bb2", null ],
    [ "statusBar", "class_ui___view.html#a9575ad459bd5c23da220c292422207e7", null ]
];