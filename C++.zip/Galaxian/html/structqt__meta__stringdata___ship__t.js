var structqt__meta__stringdata___ship__t =
[
    [ "data", "structqt__meta__stringdata___ship__t.html#a484a5a65950321516c0aaf8e37daa62a", null ],
    [ "stringdata0", "structqt__meta__stringdata___ship__t.html#aae9ebe440279cf4251aa0e8e9d475e57", null ]
];