var hierarchy =
[
    [ "dbManagement", "classdb_management.html", null ],
    [ "QGraphicsPixmapItem", null, [
      [ "Bullet", "class_bullet.html", null ],
      [ "Enemy", "class_enemy.html", [
        [ "Alien", "class_alien.html", null ],
        [ "Boss", "class_boss.html", null ],
        [ "Invader", "class_invader.html", null ],
        [ "Kamikaze", "class_kamikaze.html", null ],
        [ "Monster", "class_monster.html", null ]
      ] ],
      [ "Ship", "class_ship.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ],
      [ "View", "class_view.html", null ]
    ] ],
    [ "QObject", null, [
      [ "Bullet", "class_bullet.html", null ],
      [ "Enemy", "class_enemy.html", null ],
      [ "Ship", "class_ship.html", null ]
    ] ],
    [ "qt_meta_stringdata_Bullet_t", "structqt__meta__stringdata___bullet__t.html", null ],
    [ "qt_meta_stringdata_Enemy_t", "structqt__meta__stringdata___enemy__t.html", null ],
    [ "qt_meta_stringdata_MainWindow_t", "structqt__meta__stringdata___main_window__t.html", null ],
    [ "qt_meta_stringdata_Ship_t", "structqt__meta__stringdata___ship__t.html", null ],
    [ "qt_meta_stringdata_View_t", "structqt__meta__stringdata___view__t.html", null ],
    [ "Ui_MainWindow", "class_ui___main_window.html", [
      [ "Ui::MainWindow", "class_ui_1_1_main_window.html", null ]
    ] ],
    [ "Ui_View", "class_ui___view.html", [
      [ "Ui::View", "class_ui_1_1_view.html", null ]
    ] ]
];