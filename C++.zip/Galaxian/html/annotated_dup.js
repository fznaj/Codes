var annotated_dup =
[
    [ "Ui", "namespace_ui.html", "namespace_ui" ],
    [ "Alien", "class_alien.html", "class_alien" ],
    [ "Boss", "class_boss.html", "class_boss" ],
    [ "Bullet", "class_bullet.html", "class_bullet" ],
    [ "dbManagement", "classdb_management.html", "classdb_management" ],
    [ "Enemy", "class_enemy.html", "class_enemy" ],
    [ "Invader", "class_invader.html", "class_invader" ],
    [ "Kamikaze", "class_kamikaze.html", "class_kamikaze" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Monster", "class_monster.html", "class_monster" ],
    [ "qt_meta_stringdata_Bullet_t", "structqt__meta__stringdata___bullet__t.html", "structqt__meta__stringdata___bullet__t" ],
    [ "qt_meta_stringdata_Enemy_t", "structqt__meta__stringdata___enemy__t.html", "structqt__meta__stringdata___enemy__t" ],
    [ "qt_meta_stringdata_MainWindow_t", "structqt__meta__stringdata___main_window__t.html", "structqt__meta__stringdata___main_window__t" ],
    [ "qt_meta_stringdata_Ship_t", "structqt__meta__stringdata___ship__t.html", "structqt__meta__stringdata___ship__t" ],
    [ "qt_meta_stringdata_View_t", "structqt__meta__stringdata___view__t.html", "structqt__meta__stringdata___view__t" ],
    [ "Ship", "class_ship.html", "class_ship" ],
    [ "Ui_MainWindow", "class_ui___main_window.html", "class_ui___main_window" ],
    [ "Ui_View", "class_ui___view.html", "class_ui___view" ],
    [ "View", "class_view.html", "class_view" ]
];