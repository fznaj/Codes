var class_kamikaze =
[
    [ "Kamikaze", "class_kamikaze.html#a301979801cec9bac88377f4a2156cdd0", null ]
];