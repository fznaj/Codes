var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a34c4b4207b46d11a4100c9b19f0e81bb", null ],
    [ "playerOptions", "class_main_window.html#ac6d41b0737b94e5ea1523aaeef21fae1", null ],
    [ "setGrid", "class_main_window.html#a7d23c6dfe1443aacee7ebe5daba4d499", null ],
    [ "setLabel", "class_main_window.html#abfe4dc00a3cdbc78dfaef696cd080d53", null ],
    [ "start", "class_main_window.html#a13ad685d0e6e67809bd7fbdc309b1593", null ]
];