var class_monster =
[
    [ "Monster", "class_monster.html#a09962af9eccd24162ee3e3ffc738afc9", null ]
];