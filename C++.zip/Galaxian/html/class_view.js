var class_view =
[
    [ "View", "class_view.html#a51994a4d90203edfd357abea7d967fd3", null ],
    [ "~View", "class_view.html#ad0dc854db9aabbea98a334dec89f785c", null ],
    [ "attack", "class_view.html#a209c29db0cde8d760424e7953c142369", null ],
    [ "displayScore", "class_view.html#a74d02e69b47e1c1460c19fa9d1404215", null ],
    [ "eliminateEnemy", "class_view.html#a6d21942b58143f63afebcc8e8567bacc", null ],
    [ "keyPressEvent", "class_view.html#a452654c8f3386cb9a4bd6952f24b729b", null ],
    [ "levelBreak", "class_view.html#a712f0035b1029c609dba9ec0d13e1905", null ],
    [ "setLife", "class_view.html#a15d891d5b3a2a2ec881caf335865b735", null ],
    [ "showShip", "class_view.html#a9af9f5bf06400bdcad76dd19dc27a914", null ],
    [ "swarm", "class_view.html#a0d660f52f5b47c576ae743b2ea560c77", null ],
    [ "updateShip", "class_view.html#a1692de107afe77bb44aa997287c10f20", null ]
];