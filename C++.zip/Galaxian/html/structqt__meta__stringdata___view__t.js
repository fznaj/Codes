var structqt__meta__stringdata___view__t =
[
    [ "data", "structqt__meta__stringdata___view__t.html#a3f1261da45be0dd1b97fff4d866b9151", null ],
    [ "stringdata0", "structqt__meta__stringdata___view__t.html#a44b9097f1ff5601876ac1dee32b6f301", null ]
];