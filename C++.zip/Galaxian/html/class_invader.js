var class_invader =
[
    [ "Invader", "class_invader.html#a89c2e3fcc9733a1def4a078a5400a655", null ]
];