var structqt__meta__stringdata___main_window__t =
[
    [ "data", "structqt__meta__stringdata___main_window__t.html#a8f79e56d12892a8825330286a07da625", null ],
    [ "stringdata0", "structqt__meta__stringdata___main_window__t.html#af3cfc85ae228443d9e264713dd0a854f", null ]
];