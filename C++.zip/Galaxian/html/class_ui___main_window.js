var class_ui___main_window =
[
    [ "retranslateUi", "class_ui___main_window.html#a097dd160c3534a204904cb374412c618", null ],
    [ "setupUi", "class_ui___main_window.html#acf4a0872c4c77d8f43a2ec66ed849b58", null ],
    [ "centralWidget", "class_ui___main_window.html#a30075506c2116c3ed4ff25e07ae75f81", null ],
    [ "graphicsView", "class_ui___main_window.html#a713d8e541d9de8389ad4292131dc931a", null ],
    [ "mainToolBar", "class_ui___main_window.html#a5172877001c8c7b4e0f6de50421867d1", null ],
    [ "menuBar", "class_ui___main_window.html#a2be1c24ec9adfca18e1dcc951931457f", null ],
    [ "statusBar", "class_ui___main_window.html#a50fa481337604bcc8bf68de18ab16ecd", null ]
];