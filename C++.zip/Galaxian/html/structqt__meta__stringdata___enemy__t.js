var structqt__meta__stringdata___enemy__t =
[
    [ "data", "structqt__meta__stringdata___enemy__t.html#a4dd152782e1d5b07f1fdc4e76044a232", null ],
    [ "stringdata0", "structqt__meta__stringdata___enemy__t.html#aa0c68896de6e724f12d52cdaab472241", null ]
];