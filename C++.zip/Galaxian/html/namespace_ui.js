var namespace_ui =
[
    [ "MainWindow", "class_ui_1_1_main_window.html", null ],
    [ "View", "class_ui_1_1_view.html", null ]
];