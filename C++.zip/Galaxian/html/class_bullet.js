var class_bullet =
[
    [ "Bullet", "class_bullet.html#a3d9f64399991ef430df460cac893b731", null ],
    [ "enemyFired", "class_bullet.html#ae67c5eda946e134ce52c956fdb25540a", null ],
    [ "fireShip", "class_bullet.html#a361b9081643ca9093fa409fdaee99dbf", null ],
    [ "move", "class_bullet.html#a6140db968c42c05e829e142f74f20b16", null ],
    [ "shipFired", "class_bullet.html#a89578770739b2f11c8e9b9dc9f65ff9d", null ]
];