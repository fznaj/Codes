var searchData=
[
  ['checklife',['checkLife',['../class_ship.html#a923704bc743b0af493abaa59e3fa8cf4',1,'Ship']]],
  ['create',['create',['../classdb_management.html#a9538321b5c21919a1aa63c23f382da53',1,'dbManagement']]]
];
