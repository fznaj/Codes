var searchData=
[
  ['retranslateui',['retranslateUi',['../class_ui___main_window.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow::retranslateUi()'],['../class_ui___view.html#a587c173f7ee63dc03d8754dd14324eb4',1,'Ui_View::retranslateUi()']]]
];
