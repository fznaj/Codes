var searchData=
[
  ['boss',['Boss',['../class_boss.html',1,'']]],
  ['bullet',['Bullet',['../class_bullet.html',1,'']]]
];
