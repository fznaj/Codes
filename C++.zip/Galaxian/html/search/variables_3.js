var searchData=
[
  ['graphicsview',['graphicsView',['../class_ui___main_window.html#a713d8e541d9de8389ad4292131dc931a',1,'Ui_MainWindow::graphicsView()'],['../class_ui___view.html#a47bef1bf268937bf725696487ea64327',1,'Ui_View::graphicsView()']]]
];
