var searchData=
[
  ['ui',['Ui',['../namespace_ui.html',1,'']]],
  ['ui_5fmainwindow',['Ui_MainWindow',['../class_ui___main_window.html',1,'']]],
  ['ui_5fmainwindow_2eh',['ui_mainwindow.h',['../ui__mainwindow_8h.html',1,'']]],
  ['ui_5fview',['Ui_View',['../class_ui___view.html',1,'']]],
  ['ui_5fview_2eh',['ui_view.h',['../ui__view_8h.html',1,'']]],
  ['updatescore',['updateScore',['../classdb_management.html#aa052646322548e67636680a8f2485a52',1,'dbManagement']]],
  ['updateship',['updateShip',['../class_view.html#a1692de107afe77bb44aa997287c10f20',1,'View']]]
];
