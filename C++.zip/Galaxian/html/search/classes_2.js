var searchData=
[
  ['dbmanagement',['dbManagement',['../classdb_management.html',1,'']]]
];
