var searchData=
[
  ['playeroptions',['playerOptions',['../class_main_window.html#ac6d41b0737b94e5ea1523aaeef21fae1',1,'MainWindow']]]
];
