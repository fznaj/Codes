var searchData=
[
  ['updatescore',['updateScore',['../classdb_management.html#aa052646322548e67636680a8f2485a52',1,'dbManagement']]],
  ['updateship',['updateShip',['../class_view.html#a1692de107afe77bb44aa997287c10f20',1,'View']]]
];
