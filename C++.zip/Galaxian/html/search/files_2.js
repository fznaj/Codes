var searchData=
[
  ['dbmanagement_2ecpp',['dbmanagement.cpp',['../dbmanagement_8cpp.html',1,'']]],
  ['dbmanagement_2eh',['dbmanagement.h',['../dbmanagement_8h.html',1,'']]]
];
