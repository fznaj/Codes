var searchData=
[
  ['view',['View',['../class_ui_1_1_view.html',1,'Ui::View'],['../class_view.html',1,'View'],['../class_view.html#a51994a4d90203edfd357abea7d967fd3',1,'View::View()']]],
  ['view_2ecpp',['view.cpp',['../view_8cpp.html',1,'']]],
  ['view_2eh',['view.h',['../view_8h.html',1,'']]]
];
