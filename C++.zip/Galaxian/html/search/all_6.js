var searchData=
[
  ['gethighscore',['getHighScore',['../classdb_management.html#ae83c92032ee974b5eba2c853fa54f571',1,'dbManagement']]],
  ['getid',['getId',['../class_enemy.html#afcf7eb8f736fedffe85240b494ba5744',1,'Enemy::getId()'],['../class_ship.html#a1d984a7dfa5335759fa561122c73f189',1,'Ship::getId()']]],
  ['getlife',['getLife',['../class_ship.html#abe311a3ac4d5c5da22818475e6fbcf35',1,'Ship']]],
  ['getpoints',['getPoints',['../class_enemy.html#a5e0122fd418463449c03131663f81a1b',1,'Enemy']]],
  ['getscore',['getScore',['../class_ship.html#a19194004cbe09e343c5793675638cf90',1,'Ship']]],
  ['graphicsview',['graphicsView',['../class_ui___main_window.html#a713d8e541d9de8389ad4292131dc931a',1,'Ui_MainWindow::graphicsView()'],['../class_ui___view.html#a47bef1bf268937bf725696487ea64327',1,'Ui_View::graphicsView()']]]
];
