var searchData=
[
  ['view',['View',['../class_view.html#a51994a4d90203edfd357abea7d967fd3',1,'View']]]
];
