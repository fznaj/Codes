var searchData=
[
  ['dbmanagement',['dbManagement',['../classdb_management.html#a66274ad5f87935cc03e2fff81ece4ae1',1,'dbManagement']]],
  ['displayscore',['displayScore',['../class_view.html#a74d02e69b47e1c1460c19fa9d1404215',1,'View']]]
];
