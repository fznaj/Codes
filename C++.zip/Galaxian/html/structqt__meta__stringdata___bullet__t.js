var structqt__meta__stringdata___bullet__t =
[
    [ "data", "structqt__meta__stringdata___bullet__t.html#a04686e48c8734c974500d60302b85dca", null ],
    [ "stringdata0", "structqt__meta__stringdata___bullet__t.html#a70636793472081abc1bfea81961dc10e", null ]
];