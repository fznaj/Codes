var classdb_management =
[
    [ "dbManagement", "classdb_management.html#a66274ad5f87935cc03e2fff81ece4ae1", null ],
    [ "addPlayer", "classdb_management.html#a055f00f6cb675d5acf53d5f8fd2edebf", null ],
    [ "create", "classdb_management.html#a9538321b5c21919a1aa63c23f382da53", null ],
    [ "getHighScore", "classdb_management.html#ae83c92032ee974b5eba2c853fa54f571", null ],
    [ "init", "classdb_management.html#ad189e1a0b8ae82d49dfd3adbdb191e93", null ],
    [ "updateScore", "classdb_management.html#aa052646322548e67636680a8f2485a52", null ]
];