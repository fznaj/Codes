var class_boss =
[
    [ "Boss", "class_boss.html#ae7a383545d7450c2986450bff8651cc6", null ]
];