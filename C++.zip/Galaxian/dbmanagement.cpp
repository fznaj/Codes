#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>
#include <QApplication>

#include "dbmanagement.h"

dbManagement::dbManagement()
{
    init();
    create();
}

void dbManagement::init(){
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("database/db");
    if (!db.open()){
        QMessageBox::critical(nullptr, QObject::tr("Cannot open database"),
                              QObject::tr("Unable to establish a database connection.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
        QApplication::quit();
    }
}

void dbManagement::create(){
    QSqlQuery query;
    query.exec("create table if not exists player(id integer primary key autoincrement not null,"
               "username varchar(20), score int)");
}

bool dbManagement::addPlayer(const QString &userName, int score){
    bool success = false;
    QSqlQuery query;
    query.prepare("INSERT INTO player(username, score) VALUES (?, ?)");
    query.addBindValue(userName);
    query.addBindValue(score);
    if(query.exec()){
        success = true;
    }else{
        qDebug() << "addPlayer error:  "
                 << query.lastError();
    }
    return success;
}

bool dbManagement::updateScore(int newScore,QString user){
    bool success = false;
    QSqlQuery query;
    query.prepare("UPDATE player SET score = ? WHERE username = ?");
    query.addBindValue(newScore);
    query.addBindValue(user);
    if(query.exec()){
        success = true;
    }else{
        qDebug() << "updateScore error:  "
                 << query.lastError();
    }
    return success;
}

QString dbManagement::getHighScore(){
    QSqlQuery query;
    query.exec("SELECT count(*) FROM player");
    query.first();
    if(query.value(0)>0){
        query.exec("SELECT score FROM player WHERE score = (SELECT max(score) FROM player)");
        query.first();
        return query.value(0).toString();
    }else{
        return "0";
    }
}
