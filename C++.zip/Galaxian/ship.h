#ifndef SHIP_H
#define SHIP_H

#include <QObject>
#include <QGraphicsPixmapItem>
#include <QKeyEvent>
#include <QTimer>

#include "bullet.h"

/**
 * @brief The Ship class This class represents the ship
 */
class Ship : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:

    /**
     * @brief Ship Constructor
     * @param id the ship's id
     * @param pixmap the ship's pixmap
     * @param x the abscissa on the scene
     * @param y the ordinate on the scene
     * @param life the ship's life
     * @param score the ship's score
     * @param parent
     */
    Ship(int id, const QPixmap &pixmap, int x, int y, int life, int score, QGraphicsItem *parent=0);

    /**
     * @brief moveRight moves the ship right
     */
    void moveRight();

    /**
     * @brief moveLeft moves the ship left
     */
    void moveLeft();

    /**
     * @brief getLife getter of the ship(s life
     * @return the ship's life
     */
    int getLife();

    /**
     * @brief setLife setter of the ship's life
     * @param newLife the new life
     */
    void setLife(int newLife);

    /**
     * @brief getId getter of the ship's id
     * @return the ship's id
     */
    int getId();

    /**
     * @brief getScore getter of the ship's score
     * @return the ship's score
     */
    int getScore();

    /**
     * @brief fire throws bullets towards the enemies
     */
    void fire();

    /**
     * @brief checkLife checks if the ship's life > 0
     * @return true if it still got lives, false otherwise
     */
    bool checkLife();
private:

    /**
     * @brief id the ship's id
     */
    int id;

    /**
     * @brief life the ship's life
     */
    int life;

    /**
     * @brief score the ship's score
     */
    int score;

    /**
     * @brief timer used to move the bullet towards the enemies
     */
    QTimer *timer;

    /**
     * @brief bullet the bullet used to attack the enemies
     */
    Bullet *bullet;
public slots:

    /**
     * @brief setScore setter of the ship's score
     * @param type the enemy's type (1,2,3,4 or 5)
     * @param item the enemy
     * @param points enemy's points
     */
    void setScore(int type,QGraphicsItem * item,int points);
signals:

    /**
     * @brief scoreChanged emitted when an enemy is hit to change the ship's score
     */
    void scoreChanged(int,int);

    /**
     * @brief enemyPos emitted when an enemy is hit to get the enemy's position
     * @param type the enemy's type
     * @param item the enemy
     */
    void enemyPos(int type,QGraphicsItem *item);
};

#endif // SHIP_H
