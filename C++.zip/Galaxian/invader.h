#ifndef INVADER_H
#define INVADER_H

#include "enemy.h"


/**
 * @brief The Invader class this class represents the type 3 of the enemies
 */
class Invader : public Enemy
{
public:

    /**
     * @brief Invader Constructor with parameters
     * @param id the invader's id
     * @param pixmap the pixmap that represents the invader
     * @param x the abscissa of the invader's position on the scene
     * @param y the oordinate of the invader's position on the scene
     * @param points the number of points that are added to the ship's score
     * when the invader is hit by the ship's bullet
     */
    Invader(int id,const QPixmap &pixmap,int x, int y, int points);
};

#endif // INVADER_H
