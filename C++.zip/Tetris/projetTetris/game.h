#ifndef GAME_H
#define GAME_H

#include <QElapsedTimer>
#include <QKeyEvent>
#include <QTimer>
#include <QWidget>

class Board;
class View;
class Observer;

/**
 * @brief The Game class is the controller
 * it contains slots and signals
 */

class Game : public QWidget {
    Q_OBJECT

public:

    /**
     * @brief Game Constructor with parameters
     * @param board a pointer of a Board
     * @param view a pointer of a View
     * @param parent QWidget
     */
    Game( Board* board, View* view, QWidget* parent = 0 );

    void addObserver(Observer *obs);

    void removeObserver(Observer *obs);

    void notify();

    void update();

    /**
     * @brief onPause pauses the game
     */
    void onPause();

    /**
     * @brief onResume resumes the game where it was left off
     */
    void onResume();

    /**
     * @brief onMove moves the piece left or right
     * @param e the key pressed on the keyboard
     */
    void onMove(QKeyEvent*e);

    /**
     * @brief onRotate rotates a piece
     */
    void onRotate();

    /**
     * @brief onDropEnabled either starts or stops the drop
     * @param enabled boolean that indicates whether to drop the piece or not
     */
    void onDropEnabled( bool enabled );

    /**
     * @brief onGameOver stops the timer and ends the game if
     * the score has reached 800 or the number of cleared lines
     * is 30 or the time is up (after 1h) or the grid is full.
     */
    void onGameOver();

    /**
     * @brief startMaxTimer starts the maxTimer
     */
    void startMaxTimer();

public slots:

    /**
     * @brief onPlay plays the game
     */
    void onPlay();

    /**
     * @brief onStart slot for starting the game
     */
    void onStart();

    /**
     * @brief onTogglePause resumes if the game is paused,
     * pauses the game if it's not paused yet
     */
    void onTogglePause();

signals:

    /**
     * @brief scoreChanged signal that's emitted whenever the score is changed
     * @param score the new score to be displayed
     */
    void scoreChanged(int score);

    /**
     * @brief levelUp is emitted whenever the level changes
     * @param level the new level
     */
    void levelUp(int level);

    /**
     * @brief linesRemoved is emitted whenever there are lines that were cleared
     * @param number the new number of the lines cleared
     */
    void linesRemoved(int number);

    /**
     * @brief gameOver is emitted when the game is over
     */
    void gameOver();

    /**
     * @brief winner is emitted when the player wins the game
     */
    void winner();

    /**
     * @brief timeIsUp is emitted when the time's up
     */
    void timeIsUp();

private:

    /**
     * @brief onAction takes a pointer of a function in
     * the Board class and calls it
     */
    void onAction( void ( Board::*action )() );

private:

    /**
     * @brief board a pointer of Board
     */
    Board* board;

    /**
     * @brief view a pointer of View
     */
    View* view;

    /**
     * @brief timer the timer of the game
     */
    QTimer timer;

    /**
     * @brief maxTimer maximum time after
     * which the game is over
     */
    QElapsedTimer maxTimer;

    /**
     * @brief observers
     */
    std::vector<Observer*> observers;

};

#endif
