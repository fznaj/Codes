#include "board.h"
#include <numeric>
#include <ctime>
#include <stdexcept>
#include <exception>

Board::Board( int widthBlocks, int heightBlocks,endOfGame eog) :
    width( widthBlocks ), height( heightBlocks ),eog(eog){
    if( width <= 0 || height <= 0 ) {
        throw std::invalid_argument( "Width and height of the grid must be > 0" );
    }
    srand(time(0));
    resetGame();
}

const Piece& Board::getCurrentPiece() const {
    return currentPiece;
}

Piece Board::getNextPiece(){
    return nextPiece;
}

void Board::play() {
    Piece piece;
    nextPiece = Piece::generateRandom();
    if( currentPiece.isEmpty() ) {
        dropEnabled=false;
        counter = 0;
        currentPiece = Piece::generateRandom();
        int xPoints =(getWidth() / 2 )*BLOCK_SIZE;
        if( currentPiece.getSize() % 2 == 1 ) {
            xPoints += HALF_BLOCK_SIZE;
        }
        currentPiece.setPosition( xPoints, 0 );
        if( hasCollisions( currentPiece ) ) {
            gameOver = true;
        }
    }
    int speed = dropEnabled ? MAX_SPEED : speedPiece;
    piece = currentPiece;
    piece.setPosition( currentPiece.getXPoints(), currentPiece.getYPoints() + speed );

    if( !hasCollisions( piece ) ) {
        currentPiece = piece;
        counter = 0;
    } else {
        while( hasCollisions( piece ) ) {
            piece.setPosition( piece.getXPoints(), piece.getYPoints() - 1 );
        }
        if(counter >= maxCount) {
            currentPiece = Piece();
            for( int xBlocks = 0; xBlocks < piece.getSize(); ++xBlocks ) {
                for( int yBlocks = 0; yBlocks < piece.getSize(); ++yBlocks ) {
                    int blockType = piece.getBlockType( xBlocks, yBlocks );
                    if( blockType != 0 ) {
                        int xPoints = piece.getBlockXPoints( xBlocks );
                        int yPoints = piece.getBlockYPoints( yBlocks );
                        grid[ yPoints / BLOCK_SIZE ][  xPoints / BLOCK_SIZE ] = blockType;
                    }
                }
            }
            clearLine();
            increaseScore();
        } else {
            currentPiece = piece;
            ++counter;
        }
        if(isGameOver()) {
            return;
        }
    }
}

bool Board::isGameOver() const {
    return gameOver;
}

bool Board::isWinner() const{
    if(eog==endOfGame::scoreEnd){
        return scorePlayer >= 800;
    }else if(eog==endOfGame::linesEnd){
        return linesCleared >= 30;
    }
    return false;
}

endOfGame Board::getEndOfGame() const{
    return eog;
}

int Board::getScore() const {
    return scorePlayer;
}

int Board::getLevel() const{
    return level;
}

int Board::getClearedLines() const{
    return linesCleared;
}

void Board::resetGame() {
    currentPiece = Piece();
    grid.clear();
    grid.resize( getHeight() );
    for( std::vector< int >& row : grid ) {
        row.resize( getWidth() );
    }
    speedPiece = MIN_SPEED;
    scorePlayer = 0;
    level=1;
    linesCleared = 0;
    dropEnabled=false;
    dropCount=0;
    counter=0;
    gameOver = false;
}

void Board::rotate() {
    Piece piece = currentPiece;
    piece.rotate();
    if( !hasCollisions( piece ) ) {
        currentPiece = piece;
        return;
    }

    piece.setPosition( piece.getXPoints() + BLOCK_SIZE, piece.getYPoints() );
    if( !hasCollisions( piece ) ) {
        currentPiece = piece;
        return;
    }

    piece.setPosition( piece.getXPoints() - 2*BLOCK_SIZE, piece.getYPoints() );
    if( !hasCollisions( piece ) ) {
        currentPiece = piece;
        return;
    }
}

void Board::moveLeft() {
    moveX( -BLOCK_SIZE );
}

void Board::moveRight() {
    moveX( BLOCK_SIZE );
}

void Board::moveX( int offsetPoints ) {
    Piece piece = currentPiece;
    piece.setPosition( piece.getXPoints() + offsetPoints, piece.getYPoints() );
    if( !hasCollisions( piece ) ) {
        currentPiece = piece;
    }
}

void Board::startDrop() {
    dropEnabled=true;
}

void Board::stopDrop() {
    dropEnabled = false;
}

int Board::getWidth() const {
    return width;
}

int Board::getHeight() const {
    return height;
}

int Board::getWidthPoints() const {
    return getWidth()*BLOCK_SIZE;
}

int Board::getHeightPoints() const {
    return getHeight()*BLOCK_SIZE;
}

int Board::getBlockType( int xBlocks, int yBlocks ) const {
    if( xBlocks < 0 || getWidth() <= xBlocks || getHeight() <= yBlocks ) {
        return -1;
    } else if( yBlocks < 0 ) {
        return 0;
    }
    return grid[ yBlocks ][ xBlocks ];
}

bool Board::hasCollisions( const Piece& piece ) {
    dropCount=0;
    for( int xBlocks = 0; xBlocks < piece.getSize(); ++xBlocks ) {
        for( int yBlocks = 0; yBlocks < piece.getSize(); ++yBlocks ) {
            ++dropCount;
            if(piece.getBlockType( xBlocks, yBlocks ) > 0 &&
                    isFullBlock( piece.getBlockXPoints(xBlocks),piece.getBlockYPoints(yBlocks))){
                return true;
            }
        }
    }
    return false;
}

bool Board::isFullBlock( int xPoints, int yPoints ) const {
    int xBlocks = ( xPoints < 0 ) ? -1 : xPoints / BLOCK_SIZE;
    int yTopBlocks = yPoints - HALF_BLOCK_SIZE;
    if( getBlockType( xBlocks, yTopBlocks / BLOCK_SIZE ) ) {
        return true;
    }
    int yBottomBlocks = yPoints + HALF_BLOCK_SIZE;
    if( yTopBlocks % BLOCK_SIZE != 0 && getBlockType( xBlocks, yBottomBlocks / BLOCK_SIZE ) ) {
        return true;
    }

    return false;
}

void Board::clearLine() {
    numberLinesCleared=0;
    for( int i = height - 1; i >= 0; --i ) {
        int cpt = std::accumulate(
                    grid[ i ].begin(),
                    grid[ i ].end(),
                    0,
                    []( int a, int b ) { return ( b == 0 ) ? a : a + 1; }
        );

        if( cpt == 0 ) {
            return;
        } else if( cpt == getWidth() ) {
            grid.erase( grid.begin() + i );
            std::vector< int > v( getWidth() );
            grid.insert( grid.begin(), v );
            ++linesCleared;
            ++i;
            levelUp();
        }
    }
    numberLinesCleared = linesCleared;
}

void Board::increaseScore() {
    if(numberLinesCleared<=1){
        scorePlayer+= 40*numberLinesCleared+dropCount;
    }else if(numberLinesCleared==2){
        scorePlayer+= 100*numberLinesCleared+dropCount;
    }else if(numberLinesCleared==3){
        scorePlayer+= 300*numberLinesCleared+dropCount;
    }else if(numberLinesCleared ==4){
        scorePlayer+= 1200*numberLinesCleared+dropCount;
    }
    return;
}

void Board::levelUp() {
    if(linesCleared%10==0){
        if(level<MAX_LEVEL){
            ++level;
        }
        if( speedPiece < MAX_SPEED ) {
            ++speedPiece;
        }
    }
}
