#ifndef BOARD_H
#define BOARD_H

#include "piece.h"

enum endOfGame{scoreEnd,linesEnd,timerEnd,fullGrid};

/*!
 * \brief The Board class is the model, it's where the game is played.
 * It's a rectangular grid with blocks that contain pieces
 * and has got default height and width.
 */

class Board
{
    /**
     * @brief MIN_SPEED minimum speed of a piece
     */
    static const int MIN_SPEED = 1;

    /**
     * @brief MAX_SPEED maximum speed of a piece
     */
    static const int MAX_SPEED = 10;

    /**
     * @brief DEFAULT_WIDTH default width of the grid
     */
    static const int DEFAULT_WIDTH = 10;

    /**
     * @brief DEFAULT_HEIGHT default height of the grid
     */
    static const int DEFAULT_HEIGHT = 20;

    /**
     * @brief MAX_LEVEL maximum level to be reached
     */
    static const int MAX_LEVEL = 10;

    /**
     * @brief maxCount maximum count of touch, if a falling piece
     * touches another one
     */
    static const int maxCount = 20;

public:
    /**
     * @brief Board Constructor with two parameters, assigns default values
     * to width and height and resets the game
     * @param widthGrid width of the grid
     * @param heightGrid height of the grid
     * @param eog one of the values of the endofgame enumeration
     */
    Board(int widthGrid=DEFAULT_WIDTH,int heightGrid=DEFAULT_HEIGHT, endOfGame eog=endOfGame::fullGrid);

    /**
     * @brief play:
     *          -> generates a new piece
     *          -> drops it while there are no collisions
     *          -> clears lines if any
     *          -> updates score, level & speed
     */
    void play();

    /**
     * @brief isGameOver checks if the game is over :
     *          -> if the grid is full
     * @return a boolean
     */
    bool isGameOver() const;

    /**
     * @brief isWinner checks if the player has won the game
     *          -> or if the score has reached 800
     *          -> or if the player has done at least 30 lines
     * @return a boolean
     */
    bool isWinner() const;

    /**
     * @brief getScore gets the score of the player
     * @return an integer representing the score of the player
     */
    int getScore() const;

    /**
     * @brief getClearedLines gets the number of the cleared lines
     * @return an integer representing the number of cleared lines
     */
    int getClearedLines() const;

    /**
     * @brief getLevel gets the level
     * @return an integer representing the level
     */
    int getLevel() const;

    /**
     * @brief resetGame creates a new piece, clears the grid
     * and initializes the speed of the piece, the score,the level and
     * the linesCleard.
     */
    void resetGame();

    /**
     * @brief getCurrentPiece gets the current piece
     * @return a Piece
     */
    const Piece& getCurrentPiece() const;

    /**
     * @brief rotate rotates a piece
     */
    void rotate();

    /**
     * @brief moveLeft moves a piece to the left
     */
    void moveLeft();

    /**
     * @brief moveRight moves a piece to the right
     */
    void moveRight();

    /**
     * @brief startDrop drops the piece
     */
    void startDrop();

    /**
     * @brief stopDrop stops dropping the piece
     */
    void stopDrop();

    /**
     * @brief getWidth gets the width of the grid
     * @return an int that's the width
     */
    int getWidth() const;

    /**
     * @brief getEof getter of the end of game
     * @return a constant from the enumeration endOfGame
     */
    endOfGame getEndOfGame() const;

    /**
     * @brief getHeight gets the height of the grid
     * @return an int that's the height
     */
    int getHeight() const;

    /**
     * @brief getWidthPoints gets the number of blocks
     * horizontally used by every piece in the board
     * @return an integer
     */
    int getWidthPoints() const;

    /**
     * @brief getHeightPoints gets the number of blocks
     * vertically used by every piece on the board
     * @return
     */
    int getHeightPoints() const;

    /**
     * @brief getBlockType the type of each square in the grid
     * @param xBlocks abscissa
     * @param yBlocks ordinate
     * @return 0 if empty, -1 if outside the matrix & an integer between 1 and 7
     * depending on the piece
     */
    int getBlockType( int xBlocks, int yBlocks ) const;

    /**
     * @brief hasCollisions checks if a pieces has collisions while moving it left
     * or right or dropping it.
     * @param piece a piece
     * @return a boolean
     */
    bool hasCollisions( const Piece& piece );

    /**
     * @brief increaseScore calculates the score of the player
     */
    void increaseScore();

private:

    /**
     * @brief moveX moves a point horizontally
     * @param offsetPoints size of the movement
     */
    void moveX( int offsetPoints );

    /**
     * @brief isFreeBlock checks if there is already a piece in the block
     * given as a parameter or it's outside the grid
     * @param xPoints abscissa
     * @param yPoints ordinate
     * @return a boolean, true if it's a free block, false otherwise
     */
    bool isFullBlock( int xPoints, int yPoints ) const;

    /**
     * @brief clearLine removes a line if it's full of pieces
     * and updates the level and the speed
     */
    void clearLine();

    /**
     * @brief levelUp increments the level whenever there are
     * 10 cleared lines
     */
    void levelUp();

private:

    /**
     * @brief width width of the grid
     */
    int width;

    /**
     * @brief height height of the grid
     */
    int height;

    /**
     * @brief eof detection of the end of the game
     * chosen by the user
     */
    endOfGame eog;

    /**
     * @brief grid a vector of a vector representing the grid
     */
    Matrix grid;

    /**
     * @brief scorePlayer the score of the player
     */
    int scorePlayer;

    /**
     * @brief speedPiece the speed of the piece
     */
    int speedPiece;


    /**
     * @brief counter of touches between a falling piece and another one
     */
    int counter;

    /**
     * @brief currentPiece the current piece
     */
    Piece currentPiece;

    /**
     * @brief level the level
     */
    int level;

    /**
     * @brief dropEnabled when it's true the piece can be dropped,
     * when false it can't be droped
     */
    bool dropEnabled;

    /**
     * @brief linesCleared the number of the lines cleared
     */
    int linesCleared;

    /**
     * @brief numberLinesCleared the number of the lines cleared
     * that's initialized every time a new piece is dropped, it
     * can be between 1 and 4 each time.
     */
    int numberLinesCleared;

    /**
     * @brief dropCount counts the number of blocks while the piece
     * is being dropped
     */
    int dropCount;

    /**
     * @brief gameOver is true when a piece is in collision with another one
     */
    bool gameOver;
};


#endif
