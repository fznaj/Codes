#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>
#include <QDataStream>
#include <QHostAddress>

class Client : public QObject
{
    Q_OBJECT

public:
    Client(quint16 hostPort);
    void connect();
    void sendNbLinesCleared(int nbLines);

private:
    QTcpSocket *tcpSocket;
    QHostAddress hostAddress;
    quint16 hostPort;


};

#endif
