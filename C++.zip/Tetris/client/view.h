#ifndef VIEW_H
#define VIEW_H

#include <QWidget>
#include <QPushButton>
#include <QLCDNumber>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include <board.h>
#include <game.h>
#include <observer.h>
#include <client.h>

/**
 * @brief The View class the view of the game
 */
class View : public QWidget,public Observer {
    Q_OBJECT

public:
    /**
     * @brief View Constructor
     * @param parent QWidget
     */
    explicit View(QWidget* parent =0);

    /**
     *Destuctor of the class View
     */
    ~View();

    /**
     * @brief refresh repaints the view
     */
    void refresh();


protected:
    /**
     * @brief paintEvent paints the board and the pieces
     */
    void paintEvent( QPaintEvent* );

    /**
     * @brief keyPressEvent whenever a key is pressed
     * an action is processed
     * @param e the key
     */
    void keyPressEvent( QKeyEvent* e );

    /**
     * @brief keyReleaseEvent whenever a key is released
     * an action is done
     * @param e the key
     */
    void keyReleaseEvent( QKeyEvent* e );

    /**
     * @brief drawBlock draws a block on the board
     * @param xPoints abscissa
     * @param yPoints ordinate
     * @param type the type of the block
     * @param painter QPainter
     */
    void drawBlock( int xPoints, int yPoints, int type, QPainter* painter );

private:

    /**
     * @brief board the Board
     */
    Board *board;

    /**
     * @brief game the Game
     */
    Game* game;

    Client *client;

    /**
     * @brief width the width of the board
     */
    int width;

    /**
     * @brief height the height of the board
     */
    int height;

    QLabel *score;
    QLabel *linesCleared;
    QLabel *level;

    QLCDNumber *scoreNb;
    QLCDNumber *linesNb;
    QLCDNumber *levelNb;

    QVBoxLayout *infoPlayer;

    QPushButton *start;
    QPushButton *pauseResume;
    QPushButton *quit;

    QVBoxLayout *option;

    QGridLayout *grid;

    QLabel *gameIsOver;

    QHBoxLayout *layout;
public slots:

    /**
     * @brief stopGame stops the game when the grid is full
     * the player can still replay
     */
    void stopGame();

    /**
     * @brief congrats shows a congratulations window
     * if the player has accomplished his goal :
     *  -> either reach 800 points
     *  -> or clear 30 lines.
     */
    void congrats();

    /**
     * @brief timeUp the game is stopped once the timer expires
     * ( after 1h)
     */
    void timeUp();

};


#endif // VIEW_H
