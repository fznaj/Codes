#ifndef PIECE_H
#define PIECE_H

#include <vector>
#include <iostream>

/**
 * @brief Matrix a vector of vectors of integers
 * representing the type of each block
 */
typedef std::vector<std::vector<int>> Matrix;

/**
 * @brief BLOCK_SIZE default size of a block
 */
static const int BLOCK_SIZE = 12;

/**
 * @brief HALF_BLOCK_SIZE half size of a block
 */
static const int HALF_BLOCK_SIZE = BLOCK_SIZE / 2;

/**
 * @brief The Piece class a bloack that's got an abscissa
 * and an ordinate
 */
class Piece{

public:
    /**
     * @brief Piece Constructor of a piece with two parameters
     * @param xPoints the abscissa
     * @param yPoints the ordinate
     */
    Piece( int xPoints = 0, int yPoints = 0 );

    /**
     * @brief generateRandom generates a random integer and picks
     * the piece whose type corresponds to the integer generated
     * from a vector of pieces.
     * @return a randomly generated Piece
     */
    static Piece generateRandom();

    /**
     * @brief isEmpty checks if the matrix is empty
     * @return true if the matrix is empty, false otherwise
     */
    bool isEmpty() const;

    /**
     * @brief rotates a piece
     */
    void rotate();

    /**
     * @brief setPosition sets the position of a piece
     * @param xPoints the abscissa
     * @param yPoints the ordinate
     */
    void setPosition( int xPoints, int yPoints );

    /**
     * @brief getXPoints gets the abscissa
     * @return the abscissa of the piece
     */
    int getXPoints() const;

    /**
     * @brief getYPoints the ordinate
     * @return the ordinate of the piece
     */
    int getYPoints() const;

    /**
     * @brief getSize gets the size of the matrix of the piece
     * @return an integer
     */
    int getSize() const;

    /**
     * @brief getBlockType gets the type of the block in
     * the abscissa and ordinate given as parameters
     * @param innerXBlocks the abscissa
     * @param innerYBlocks the ordinate
     * @return 0 if empty block, -1 if out of the grid
     * or integer between 1 and 7 depending on the piece in it.
     */
    int getBlockType( int innerXBlocks, int innerYBlocks ) const;

    /**
     * @brief getBlockXPoints gets the abscissa in the grid
     * of the piece in the abscissa innerXBlocks
     * @param innerXBlocks abscissa
     * @return an integer
     */
    int getBlockXPoints( int innerXBlocks ) const;

    /**
     * @brief getBlockYPoints gets the ordinate in the grid
     * of the piece in the ordinate innerYBlocks
     * @param innerYBlocks ordinate
     * @return an integer
     */
    int getBlockYPoints( int innerYBlocks ) const;

private:
    /**
     * @brief Piece Constructor of a piece
     * @param matrix the matrix of the piece
     */
    explicit Piece( const Matrix& matrix );

private:
    /**
     * @brief xPointsPiece the abscissa of the piece in the matrix
     */
    int xPointsPiece;

    /**
     * @brief yPointsPiece the ordinate of the piece in the matrix
     */
    int yPointsPiece;

    /**
     * @brief pieceMatrix the matrix of the piece
     */
    Matrix pieceMatrix;

};


#endif
