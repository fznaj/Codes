#include "game.h"
#include "board.h"
#include "view.h"
#include "observer.h"

Game::Game(Board* board , View* view, QWidget* parent) :
    QWidget(parent ), board(board), view(view) {
    connect(&timer, SIGNAL(timeout()), SLOT(onPlay()));
    startMaxTimer();
}

void Game::addObserver(Observer *obs){
    observers.push_back(obs);
}

void Game::removeObserver(Observer *obs){
    if(std::find(observers.begin(), observers.end(), obs) != observers.end()){
        //        observers.erase();
    }
}

void Game::notify(){
    for(auto &obs : observers){
        obs->refresh();
    }
}

void Game::update(){
    emit scoreChanged(board->getScore());
    emit levelUp(board->getLevel());
    emit linesRemoved(board->getClearedLines());
}

void Game::onStart() {
    board->resetGame();
    onResume();
    notify();
}

void Game::onPlay() {
    board->play();
    notify();
    onGameOver();
}

void Game::onPause() {
    timer.stop();
}

void Game::onResume() {
    timer.start(30);
}

void Game::onMove(QKeyEvent *e) {
    e->key() == Qt::Key_Left ? onAction( &Board::moveLeft ) : onAction(&Board::moveRight);
}

void Game::onRotate() {
    onAction( &Board::rotate );
}

void Game::onDropEnabled( bool enabled ) {
    onAction(enabled ? &Board::startDrop : &Board::stopDrop);
}

void Game::onTogglePause() {
    timer.isActive() ? onPause() : onResume();
}

void Game::onGameOver(){
    if(board->getEndOfGame()==endOfGame::timerEnd){
        if(maxTimer.hasExpired(3600000)){
            timer.stop();
            emit timeIsUp();
        }else if(board->isGameOver()){
            timer.stop();
            emit gameOver();
        }
    }else if(board->isWinner()){
        timer.stop();
        emit winner();
    }else if(board->isGameOver()){
        timer.stop();
        emit gameOver();
    }
}

void Game::onAction( void ( Board::*action )() ) {
    if( !timer.isActive() ) {
        return;
    }
    ( board->*action )();
    notify();
}

void Game::startMaxTimer(){
    maxTimer.start();
}
