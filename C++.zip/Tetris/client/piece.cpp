#include "piece.h"
#include <stdexcept>
#include <exception>

Piece::Piece( int xPoints, int yPoints ) : xPointsPiece( xPoints ), yPointsPiece( yPoints ) {
}

Piece Piece::generateRandom() {
    static std::vector<Piece> PIECES = {
        Piece( {
            { 1, 1 },
            { 1, 1 },
        } ),
        Piece( {
            { 0, 2, 0, 0 },
            { 0, 2, 0, 0 },
            { 0, 2, 0, 0 },
            { 0, 2, 0, 0 },
        } ),
        Piece( {
            { 0, 3, 0 },
            { 0, 3, 0 },
            { 0, 3, 3 },
        } ),
        Piece( {
            { 0, 4, 0 },
            { 0, 4, 0 },
            { 4, 4, 0 },
        } ),
        Piece( {
            { 0, 5, 0 },
            { 5, 5, 5 },
            { 0, 0, 0 },
        } ),
        Piece( {
            { 6, 6, 0 },
            { 0, 6, 6 },
            { 0, 0, 0 },
        } ),
        Piece( {
            { 0, 7, 7 },
            { 7, 7, 0 },
            { 0, 0, 0 },
        } )
    };

    if(PIECES.size()==0){
        PIECES={
            Piece( {
                { 1, 1 },
                { 1, 1 },
            } ),
            Piece( {
                { 0, 2, 0, 0 },
                { 0, 2, 0, 0 },
                { 0, 2, 0, 0 },
                { 0, 2, 0, 0 },
            } ),
            Piece( {
                { 0, 3, 0 },
                { 0, 3, 0 },
                { 0, 3, 3 },
            } ),
            Piece( {
                { 0, 4, 0 },
                { 0, 4, 0 },
                { 4, 4, 0 },
            } ),
            Piece( {
                { 0, 5, 0 },
                { 5, 5, 5 },
                { 0, 0, 0 },
            } ),
            Piece( {
                { 6, 6, 0 },
                { 0, 6, 6 },
                { 0, 0, 0 },
            } ),
            Piece( {
                { 0, 7, 7 },
                { 7, 7, 0 },
                { 0, 0, 0 },
            } )
        };
    }
    int type = rand() % PIECES.size();
    Piece piece = PIECES[type];
    PIECES.erase(PIECES.begin()+type);
    return piece;
}

bool Piece::isEmpty() const {
    return pieceMatrix.empty();
}

void Piece::rotate() {
    Matrix rotatedMatrix( getSize() );
    for( int i = 0; i < getSize(); ++i ) {
        rotatedMatrix[ i ].resize( getSize() );
        for( int j = 0; j < getSize(); ++j ) {
            rotatedMatrix[ i ][ j ] = pieceMatrix[ j ][ getSize() - 1 - i ];
        }
    }
    pieceMatrix = rotatedMatrix;
}

void Piece::setPosition( int xPoints, int yPoints ) {
    xPointsPiece = xPoints;
    yPointsPiece = yPoints;
}

int Piece::getXPoints() const {
    return xPointsPiece;
}

int Piece::getYPoints() const {
    return yPointsPiece;
}

int Piece::getSize() const {
    return pieceMatrix.size();
}

int Piece::getBlockType( int innerXBlocks, int innerYBlocks ) const {
    if( innerXBlocks < 0 || getSize() <= innerXBlocks || innerYBlocks < 0 || getSize() <= innerYBlocks ) {
        return 0;
    }

    return pieceMatrix[ innerYBlocks ][ innerXBlocks ];
}

int Piece::getBlockXPoints( int innerXBlocks ) const {
    int innerXPoints = (innerXBlocks*BLOCK_SIZE) + HALF_BLOCK_SIZE;
    int innerXCenterPoints = ( getSize() * BLOCK_SIZE ) / 2;
    return xPointsPiece - innerXCenterPoints + innerXPoints;
}

int Piece::getBlockYPoints( int innerYBlocks ) const {
    int innerYPoints =(innerYBlocks*BLOCK_SIZE) + HALF_BLOCK_SIZE;
    int innerYCenterPoints = ( getSize() * BLOCK_SIZE ) / 2;
    return yPointsPiece - innerYCenterPoints + innerYPoints;
}

Piece::Piece( const Matrix& matrix ) : Piece() {
    for( const std::vector< int >& row : matrix ) {
        if( row.size() != matrix.size() ) {
            throw std::invalid_argument( "Tetris piece must be represented by a square matrix" );
        }
    }

    this->pieceMatrix = matrix;
}
