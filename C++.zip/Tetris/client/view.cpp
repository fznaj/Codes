#include "view.h"

#include <QPainter>
#include <QKeyEvent>
#include <QApplication>
#include <QStringList>
#include <QInputDialog>
#include <QMessageBox>

int modelPointsToPixels( int x ) {
    return x * 2;
}

static const int BLOCK_SIZE_PIXELS = modelPointsToPixels( BLOCK_SIZE );
static const int HALF_BLOCK_SIZE_PIXELS = BLOCK_SIZE_PIXELS / 2;

View::View( QWidget* parent ) : QWidget( parent ) {

    width = modelPointsToPixels( board->getWidthPoints() );
    height = modelPointsToPixels( board->getHeightPoints() );

    QStringList items;

    items << tr("800 points reached") << tr("30 lines cleared") <<
             tr("1h of playing") << tr("full grid");

    bool ok;
    QInputDialog id;
    QString item = id.getItem(this, tr("Welcome to Tetris"),
                              tr("Please set your game over option: "), items, 0, false, &ok);

    if (ok && !item.isEmpty()){
        if(item=="800 points reached"){
            board = new Board(10,20,endOfGame::scoreEnd);
        }else if(item=="30 lines cleared"){
            board = new Board(10,20,endOfGame::linesEnd);
        }else if(item=="1h of playing"){
            board = new Board(10,20,endOfGame::timerEnd);
        }else{
            board = new Board(10,20,endOfGame::fullGrid);
        }
        game = new Game(board, this, this);
        game->addObserver(this);
    }else {
        QApplication::quit();
    }

    score = new QLabel("Score");
    QFont font;
    font.setPointSize(8);
    font.setBold(true);
    score->setFont(font);
    linesCleared = new QLabel("Lines Cleared");
    linesCleared->setFont(font);
    level = new QLabel("Level");
    level->setFont(font);
    scoreNb = new QLCDNumber(5);
    scoreNb->setSegmentStyle(QLCDNumber::Filled);
    linesNb = new QLCDNumber(5);
    linesNb->setSegmentStyle(QLCDNumber::Filled);
    levelNb = new QLCDNumber(5);
    levelNb->setSegmentStyle(QLCDNumber::Filled);

    infoPlayer = new QVBoxLayout();
    infoPlayer->addWidget(score);
    infoPlayer->addWidget(scoreNb);
    infoPlayer->addWidget(linesCleared);
    infoPlayer->addWidget(linesNb);
    infoPlayer->addWidget(level);
    infoPlayer->addWidget(levelNb);

    start = new QPushButton("Start");
    start->setMaximumWidth(100);
    start->setFocusPolicy(Qt::NoFocus);
    pauseResume = new QPushButton("Pause/Resume");
    pauseResume->setMaximumWidth(100);
    pauseResume->setFocusPolicy(Qt::NoFocus);
    quit = new QPushButton("Quit");
    quit->setMaximumWidth(100);
    quit->setFocusPolicy(Qt::NoFocus);

    option = new QVBoxLayout();
    option->addWidget(start);
    option->addWidget(pauseResume);
    option->addWidget(quit);

    grid = new QGridLayout;
    grid->addWidget(game);
    grid->setAlignment(Qt::AlignCenter);

    connect(start, SIGNAL(clicked()), game, SLOT(onStart()));
    connect(pauseResume, SIGNAL(clicked()), game, SLOT(onTogglePause()));
    connect(quit , SIGNAL(clicked()), qApp, SLOT(quit()));
    connect(game, SIGNAL(scoreChanged(int)), scoreNb, SLOT(display(int)));
    connect(game, SIGNAL(levelUp(int)), levelNb, SLOT(display(int)));
    connect(game, SIGNAL(linesRemoved(int)),linesNb, SLOT(display(int)));
    connect(game,SIGNAL(gameOver()),this,SLOT(stopGame()));
    connect(game,SIGNAL(winner()),this,SLOT(congrats()));
    connect(game,SIGNAL(timeIsUp()),this,SLOT(timeUp()));

    layout = new QHBoxLayout();
    layout->addItem(grid);
    layout->addItem(infoPlayer);
    layout->addItem(option);
    setLayout(layout);

    setWindowTitle(tr("Tetris"));
    setStyleSheet("background-color: lightGray;");
    setFixedSize(600,500);

    client = new Client(1234);
    client->connect();
}

void View::stopGame(){
    QMessageBox over;
    over.setText("GAME OVER !");
    over.setStandardButtons(QMessageBox::Retry | QMessageBox::Ok);
    over.setStyleSheet("QLabel{min-width:500 px; font-size: 24px;font: bold} QPushButton{ width:250px; font-size: 18px; }");
    if (over.exec() == QMessageBox::Ok){
        QApplication::quit();
    }
}

void View::congrats(){
    QMessageBox msg;
    msg.setText("CONGRATULATIONS , YOU WON THE GAME !");
    msg.setStandardButtons(QMessageBox::Retry | QMessageBox::Ok);
    msg.setStyleSheet("QLabel{min-width:500 px; font-size: 24px;font: bold} QPushButton{ width:250px; font-size: 18px; }");
    if (msg.exec() == QMessageBox::Ok){
        QApplication::quit();
    }else{
        board->resetGame();
    }
}

void View::timeUp(){
    QMessageBox msg;
    msg.setText("TIME IS UP :( ");
    msg.setStandardButtons(QMessageBox::Retry | QMessageBox::Ok);
    msg.setStyleSheet("QLabel{min-width:500 px; font-size: 24px;font: bold} QPushButton{ width:250px; font-size: 18px; }");
    if (msg.exec() == QMessageBox::Ok){
        QApplication::quit();
    }else if(msg.exec()==QMessageBox::Retry){
        game->startMaxTimer();
    }
}

View::~View() {
}

void View::refresh() {
    repaint();
    game->update();
    if(board->getClearedLines()>0){
        client->sendNbLinesCleared(board->getClearedLines());
    }
}

void View::paintEvent( QPaintEvent* ) {
    QPainter painter( this );
    painter.fillRect(grid->geometry().x()-15,grid->geometry().y()-15,
                     grid->geometry().width()+10,grid->geometry().height()+7,Qt::lightGray);

    for( int x = 0; x < board->getWidth(); ++x ) {
        for( int y =0 ; y < board->getHeight(); ++y ) {
            drawBlock( x *BLOCK_SIZE + HALF_BLOCK_SIZE, y *BLOCK_SIZE + HALF_BLOCK_SIZE, board->getBlockType( x, y ), &painter );
        }
    }

    const Piece& item = board->getCurrentPiece();
    for( int x =0; x < item.getSize(); ++x ) {
        for( int y = 0; y < item.getSize(); ++y ) {
            drawBlock( item.getBlockXPoints( x), item.getBlockYPoints(y), item.getBlockType( x, y ), &painter );
        }
    }
}

void View::keyPressEvent( QKeyEvent* e ) {
    switch( e->key() ) {
    case Qt::Key_Left:
    case Qt::Key_Right:
        game->onMove(e);
        break;
    case Qt::Key_Up:
        game->onRotate();
        break;
    case Qt::Key_Down:
    case Qt::Key_Space:
        game->onDropEnabled(true);
        break;
    default:
        QWidget::keyPressEvent( e );
    }
}

void View::keyReleaseEvent( QKeyEvent* e ) {
    switch( e->key() ) {
    case Qt::Key_Down:
        game->onDropEnabled(false);
        break;
    default:
        QWidget::keyPressEvent(e);
    }
}

void View::drawBlock( int xPoints, int yPoints, int type , QPainter* painter ) {
    static const std::vector< QColor > COLOR_TABLE = {
        Qt::black,
        Qt::darkRed,
        Qt::darkGreen,
        Qt::red,
        Qt::darkCyan,
        Qt::darkMagenta,
        Qt::blue
    };

    if( type <= 0 || (int)COLOR_TABLE.size() < type ) {
        return;
    }
    int xPixels = modelPointsToPixels( xPoints ) - HALF_BLOCK_SIZE_PIXELS;
    int yPixels = modelPointsToPixels( yPoints ) - HALF_BLOCK_SIZE_PIXELS;
    painter->fillRect( xPixels, yPixels, BLOCK_SIZE_PIXELS, BLOCK_SIZE_PIXELS, COLOR_TABLE[ type - 1 ] );

}
