#include <QtNetwork>

#include "client.h"
Client::Client(quint16 hostPort)
{
    tcpSocket = new QTcpSocket();
    hostAddress = QHostAddress::Any;
    this->hostPort = hostPort;
}

void Client::connect(){
    tcpSocket->connectToHost("127.0.0.1",hostPort,QIODevice::ReadWrite);
    if(tcpSocket->waitForConnected())
    {
        QString string = "Hello";
        QByteArray array;
        array.append(string);
        qDebug()<<tcpSocket->write(array);
    }
    else
    {
        qDebug() << "couldn't connect";
    }
}

void Client::sendNbLinesCleared(int nbLines){
    std::string s = std::to_string(nbLines);
    char const *nb = s.c_str();
    qDebug() << nbLines;
    tcpSocket->write(nb);
}
