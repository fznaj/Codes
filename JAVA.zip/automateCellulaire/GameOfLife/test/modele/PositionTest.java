package modele;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author G42726
 */
public class PositionTest {

    @Test
    public void PositionGetX() {
        Position p = new Position(23, 19);
        assertEquals(p.getX(), 23);
    }

    @Test
    public void PositionGetY() {

        Position p = new Position(23, 19);
        assertEquals(p.getY(), 19);
    }

    @Test
    public void PositionGetDown() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getDown(c1);
        Position p1 = new Position(c1.getPosition().getX() + 1, c1.getPosition().getY());
        assertEquals(p1.getX(), p.getX() + 1);
    }

    @Test
    public void PositionGetUp() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUp(c1);
        Position p1 = new Position(c1.getPosition().getX() - 1, c1.getPosition().getY());
        assertEquals(p1.getX(), p.getX() - 1);
    }

    @Test
    public void PositionGetLeft() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getLeft(c1);
        Position p1 = new Position(c1.getPosition().getX(), c1.getPosition().getY() - 1);
        assertEquals(p1.getY(), p.getY() - 1);
    }

    @Test
    public void PositionGetRight() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getRight(c1);
        Position p1 = new Position(c1.getPosition().getX(), c1.getPosition().getY() + 1);
        assertEquals(p1.getY(), p.getY() + 1);
    }

    @Test
    public void PositionGetUpLeftX() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUpLeft(c1);
        Position p1 = new Position(c1.getPosition().getX() - 1, c1.getPosition().getY() - 1);
        assertEquals(p1.getX(), p.getX() - 1);
    }

    @Test
    public void PositionGetUpLeftY() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUpLeft(c1);
        Position p1 = new Position(c1.getPosition().getX() - 1, c1.getPosition().getY() - 1);
        assertEquals(p1.getY(), p.getY() - 1);
    }

    @Test
    public void PositionGetUpRightY() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUpRight(c1);
        Position p1 = new Position(c1.getPosition().getX() - 1, c1.getPosition().getY() + 1);
        assertEquals(p1.getY(), p.getY() + 1);
    }

    @Test
    public void PositionGetUpRightX() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUpRight(c1);
        Position p1 = new Position(c1.getPosition().getX() - 1, c1.getPosition().getY() + 1);
        assertEquals(p1.getX(), p.getX() - 1);
    }

    @Test
    public void PositionGetDownLeftX() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getDown(c1);
        Position p1 = new Position(c1.getPosition().getX() + 1, c1.getPosition().getY() - 1);
        assertEquals(p1.getX(), p.getX() + 1);
    }

    @Test
    public void PositionGetDownRightY() {
        Position p = new Position(23, 19);
        Cellule c1 = new Cellule(p, EtatCellule.MORTE);
        Position.getUpRight(c1);
        Position p1 = new Position(c1.getPosition().getX() + 1, c1.getPosition().getY() - 1);
        assertEquals(p1.getY(), p.getY() - 1);
    }

}
