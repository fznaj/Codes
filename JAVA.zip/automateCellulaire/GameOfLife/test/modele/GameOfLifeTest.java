package modele;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author G42726
 */
public class GameOfLifeTest {

    @Test
    public void AC() {
        GameOfLife ac = new GameOfLife(10, 20, 5);
        ac.ajouterRegle();
        assertEquals(ac.getnbGeneration(), 1);
    }

}
