package modele;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author G42726
 */
public class CelluleTest {

    @Test
    public void CelluleGetEtat() {
        Cellule cell = new Cellule(new Position(10, 20), EtatCellule.VIVANTE);
        assertEquals(cell.getEtat(), EtatCellule.VIVANTE);
    }

    @Test
    public void CelluleGetPositionX() {
        Cellule cell = new Cellule(new Position(10, 20), EtatCellule.VIVANTE);
        assertEquals(cell.getPosition().getX(), 10);
    }

    @Test
    public void CelluleGetPositionY() {
        Cellule cell = new Cellule(new Position(10, 20), EtatCellule.VIVANTE);
        assertEquals(cell.getPosition().getY(), 20);
    }

    @Test
    public void CelluleSetEtat() {
        Cellule cell = new Cellule(new Position(10, 20), EtatCellule.VIVANTE);
        cell.setEtat(EtatCellule.MORTE);
        assertEquals(cell.getEtat(), EtatCellule.MORTE);
    }

}
