package persistence.dto;

/**
 *
 * @author G39986
 */
public class ConfigurationDto extends EntityDto<Integer> {

    private int largeur;
    private int hauteur;
    private int nbCellvivanteDepart;

    public ConfigurationDto(int largeur, int hauteur, int nbCellvivanteDepart) {
        this.largeur = largeur;
        this.hauteur = hauteur;
        this.nbCellvivanteDepart = nbCellvivanteDepart;
    }

    public ConfigurationDto(Integer id, int largeur, int hauteur, int nbCellvivanteDepart) {
        this(largeur, hauteur, nbCellvivanteDepart);
        this.id = id;
    }

    public int getLargeur() {
        return largeur;
    }

    public void setLargeur(int largeur) {
        this.largeur = largeur;
    }

    public int getHauteur() {
        return hauteur;
    }

    public void setHauteur(int hauteur) {
        this.hauteur = hauteur;
    }

    public int getnbCellvivanteDepart() {
        return this.nbCellvivanteDepart;
    }

    public void setnbCellvivanteDepart(int nbcellviv) {
        this.nbCellvivanteDepart = nbcellviv;
    }
}
