package persistence.dto;

/**
 *
 * @author G39986
 */
public class CelluleDto extends EntityDto<Integer> {

    private int x;
    private int y;
    private boolean etat;
    private int idGeneration;
    private int idConfig;

    public CelluleDto(int x, int y, boolean etat, int idGen, int idConf) {
        this.x = x;
        this.y = y;
        this.etat = etat;
        this.idGeneration = idGen;
        this.idConfig = idConf;
    }

    public CelluleDto(Integer id, int x, int y, boolean etat, int idGen, int idConf) {
        this(x, y, etat, idGen, idConf);
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getIdConfig() {
        return idConfig;
    }

    public void setIdConf(int idConf) {
        this.idConfig = idConf;
    }

    public boolean getEtat() {
        return this.etat;
    }

    public int getIdGen() {
        return idGeneration;
    }

    public void setIdGen(int idGen) {
        idGeneration = idGen;
    }

    /*
    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }*/
}
