package persistence.dto;

/**
 *
 * @author G39986
 */
public class HistoriqueDto extends EntityDto<Integer> {

    private int idConfig;
    private int generation;
    private int nbCellDepart;

    public HistoriqueDto(int idConfig, int generation, int nbCellDepart) {
        this.idConfig = idConfig;
        this.generation = generation;
        this.nbCellDepart = nbCellDepart;
    }

    public HistoriqueDto(Integer id, int idConfig, int generation, int nbCellVivante) {
        this(idConfig, generation, nbCellVivante);
        this.id = id;
    }

    public int getIdConfig() {
        return idConfig;
    }

    public void setIdConfig(int idconf) {
        this.idConfig = idconf;
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int gen) {
        this.generation = gen;
    }

    public int getNbCellDepart() {
        return nbCellDepart;
    }
}
