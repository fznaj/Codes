package business;

import db.HistoriqueDB;
import java.sql.SQLException;
import persistence.dto.HistoriqueDto;

/**
 *
 * @author bilal
 */
public class HistoriqueBl {

    public static int add(HistoriqueDto cli) throws Exception {
        return HistoriqueDB.insertDb(cli);
    }

    static void delete(int id) throws Exception {
        HistoriqueDB.deleteDb(id);
    }

    public static void delete() throws Exception {
        HistoriqueDB.deleteHistoriques();
    }

    public static void update(HistoriqueDto cli) throws SQLException, Exception {
        HistoriqueDB.updateDb(cli);
    }

}
