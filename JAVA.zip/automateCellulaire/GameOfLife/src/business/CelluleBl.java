package business;

import db.CelluleDB;
import java.sql.SQLException;
import java.util.Collection;
import persistence.dto.CelluleDto;

/**
 *
 * @author bilal
 */
public class CelluleBl {

    public static int add(CelluleDto cli) throws Exception {
        return CelluleDB.insertDb(cli);
    }

    static void delete(int id) throws Exception {
        CelluleDB.deleteDb(id);
    }

    public static void delete() throws Exception {
        CelluleDB.deleteCellules();
    }

    public static void update(CelluleDto cli) throws SQLException, Exception {
        CelluleDB.updateDb(cli);
    }

    /**
     * Récupère toutes les cellules liées à une génération
     *
     * @param idGen la génération
     * @return Collection de CelluleDto
     * @throws SQLException
     * @throws Exception
     */
    public static Collection<CelluleDto> findAllColletions(int idGen) throws SQLException, Exception {
        return CelluleDB.getCellulesByGeneration(idGen);
    }
}
