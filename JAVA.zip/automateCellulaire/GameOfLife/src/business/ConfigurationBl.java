package business;

import db.ConfigurationDB;
import java.sql.SQLException;
import java.util.Collection;
import persistence.dto.ConfigurationDto;
import selDto.ConfigurationSel;

/**
 *
 * @author bilal
 */
public class ConfigurationBl {

    public static int add(ConfigurationDto cli) throws Exception {
        return ConfigurationDB.insertDb(cli);
    }

    static void delete(int id) throws Exception {
        ConfigurationDB.deleteDb(id);
    }

    public static void delete() throws Exception {
        ConfigurationDB.deleteConfigurations();
    }

    public static void update(ConfigurationDto cli) throws SQLException, Exception {
        ConfigurationDB.updateDb(cli);
    }

    /*
    static ClientDto findByLogin(String login) throws EsaleDbException {
        ClientSel sel = new ClientSel(null, null, login, null, null, null);
        Collection<ClientDto> col = ClientDB.getCollection(sel);
        if (col.size() == 1) {
            return col.iterator().next();
        } else {
            return null;
        }
    }*/
    static ConfigurationDto findById(int id) throws SQLException, Exception {
        ConfigurationSel sel = new ConfigurationSel(id);
        Collection<ConfigurationDto> col = ConfigurationDB.getCollection(sel);
        if (col.size() == 1) {
            return col.iterator().next();
        } else {
            return null;
        }
    }

    static void setactive(int id, boolean b) throws SQLException, Exception {
        ConfigurationDto cli = findById(id);
        if (cli == null) {
            //throw new EsaleBusinessException("Client (" + id + ") inconnu");
        }
        //  cli.setActive(b);
        ConfigurationDB.updateDb(cli);
    }

    static Collection<ConfigurationDto> findBySel(ConfigurationSel sel) throws SQLException, Exception {
        Collection<ConfigurationDto> col = ConfigurationDB.getCollection(sel);
        return col;
    }

    static Collection<ConfigurationDto> findAll() throws SQLException, Exception {
        ConfigurationSel sel = new ConfigurationSel(0);
        Collection<ConfigurationDto> col = ConfigurationDB.getCollection(sel);
        return col;
    }
}
