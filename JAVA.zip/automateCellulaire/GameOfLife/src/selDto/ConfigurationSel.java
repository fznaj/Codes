package selDto;

/**
 *
 * @author G39986
 */
public class ConfigurationSel {

    private int id;
    private int largeur;
    private int hauteur;
    private int nbCellvivanteDepart;
    private Boolean active;

    public ConfigurationSel(int largeur, int hauteur, int nbcellviv, Boolean active) {
        this.id = 0;
        this.largeur = largeur;
        this.hauteur = hauteur;
        this.nbCellvivanteDepart = nbcellviv;
        this.active = active;
    }

    public ConfigurationSel(int id) {
        this.id = id;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLargeur() {
        return largeur;
    }

    public void setLargeur(int largeur) {
        this.largeur = largeur;
    }

    public int getHauteur() {
        return hauteur;
    }

    public void setHauteur(int hauteur) {
        this.hauteur = hauteur;
    }

    public int getnbCellvivanteDepart() {
        return nbCellvivanteDepart;
    }

    public void setnbCellvivanteDepart(int nbcell) {
        this.nbCellvivanteDepart = nbcell;
    }

}
