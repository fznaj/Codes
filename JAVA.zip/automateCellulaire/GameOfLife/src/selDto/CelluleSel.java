package selDto;

/**
 *
 * @author G39986
 */
public class CelluleSel {

    private int id;
    private int x;
    private int y;
    private int idGeneration;
    private int idConf;

    private Boolean active;

    public CelluleSel(int x, int y, Boolean active, int idGeneration, int idConf) {
        this.id = 0;
        this.x = x;
        this.y = y;
        this.active = active;
        this.idGeneration = idGeneration;
        this.idConf = idConf;
    }

    public CelluleSel(int id) {
        this.id = id;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getidGeneration() {
        return idGeneration;
    }

    public void setidGeneration(int idGen) {
        this.idGeneration = idGen;
    }

    public int getIdConf() {
        return idConf;
    }

    public void setIdConf(int idConf) {
        this.idConf = idConf;
    }

}
