package selDto;

/**
 *
 * @author G39986
 */
public class HistoriqueSel {

    private int id;
    private int idConfig;
    private int generation;
    private int nbCellDepart;

    private Boolean active;

    public HistoriqueSel(int idconfig, int generation, int nbcell, Boolean active) {
        this.id = 0;
        this.idConfig = idconfig;
        this.generation = generation;
        this.nbCellDepart = nbcell;
        this.active = active;
    }

    public HistoriqueSel(int id) {
        this.id = id;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getidConfig() {
        return idConfig;
    }

    public void setidConfig(int x) {
        this.idConfig = x;
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int y) {
        this.generation = y;
    }

    public int getNbCellDepart() {
        return nbCellDepart;
    }

    public void setNbCellDepart(int nbCell) {
        this.nbCellDepart = nbCell;
    }

}
