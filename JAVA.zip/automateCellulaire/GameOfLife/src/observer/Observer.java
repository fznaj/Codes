package observer;

/**
 *
 * @author G39986
 */
public interface Observer {

    public void update();
}
