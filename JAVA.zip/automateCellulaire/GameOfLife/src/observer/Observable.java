package observer;

/**
 *
 * @author G39986
 */
public interface Observable {

    public void addObserver(Observer o);

    public void deletteObserver(Observer o);

    public void notifyObservers();
}
