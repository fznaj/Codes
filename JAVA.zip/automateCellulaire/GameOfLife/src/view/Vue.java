package view;
//
//import java.util.Scanner;

import business.CelluleBl;
import business.ConfigurationBl;
import business.HistoriqueBl;
import db.SequenceDB;
import persistence.dto.CelluleDto;
import persistence.dto.ConfigurationDto;
import persistence.dto.HistoriqueDto;

//import modele.AutomateCellulaire;
//import modele.EtatCellule;
//import observer.Observer;
//
///**
// * classe vue
// *
// * @author bilal
// */
//public class Vue implements Observer {
//
//    private AutomateCellulaire automate;
//    private int hauteur;
//    private int largeur;
//    private int nbCelluleVivante;
//
//    public Vue() {
//        this.hauteur = 0;
//        this.largeur = 0;
//        this.nbCelluleVivante = 0;
//        this.automate = null;
//        demarrer();
//    }
//
//    /**
//     * methode qui initialise l'automate
//     *
//     * @param longueur nombre de ligne de l'automate
//     * @param largeur nombre de colonne de l'automate
//     * @param nbCellules nombre de cellule vivante au depart
//     */
//    public void initialiser(int longueur, int largeur, int nbCellules) {
//        this.hauteur = longueur;
//        this.largeur = largeur;
//        this.nbCelluleVivante = nbCellules;
//        this.automate = new AutomateCellulaire(hauteur, this.largeur, this.nbCelluleVivante);
//        this.automate.addObserver(this);
//    }
//
//    public int info() {
//        System.out.println("1) Passez à la génération suivante.");
//        System.out.println("2) Quitter.");
//        Scanner sc = new Scanner(System.in);
//        while (!sc.hasNextInt()) {
//            System.out.println("1) Passez à la génération suivante.");
//            System.out.println("2) Quitter.");
//            sc.next();
//        }
//        int i = sc.nextInt();
//        return i;
//    }
//
//    private void demarrer() {
//
//        int longueur = longueur();
//        int largeur = largeur();
//        int nbCell = nbCellulesVivantes();
//        initialiser(longueur, largeur, nbCell);
//        update(0);
//    }
//
//    public void choix() {
//        switch (info()) {
//            case 1:
//                //this.automate.generationSuivante();
//                this.automate.ajouterRegle();
//                break;
//            case 2:
//                System.exit(0);
//                break;
//        }
//    }
//
//    public int longueur() {
//        System.out.println("Entrez le nombre de ligne de l'automate : ");
//        Scanner sc = new Scanner(System.in);
//        while (!sc.hasNextInt()) {
//            System.out.println("Entrez le nombre de ligne de l'automate : ");
//            sc.next();
//        }
//        int i = sc.nextInt();
//        return i;
//    }
//
//    public int largeur() {
//        System.out.println("Entrez le nombre de colonne de l'automate : ");
//        Scanner sc = new Scanner(System.in);
//        while (!sc.hasNextInt()) {
//            System.out.println("Entrez le nombre de colonne de l'automate : ");
//            sc.next();
//        }
//        int i = sc.nextInt();
//        return i;
//    }
//
//    public int nbCellulesVivantes() {
//        System.out.println("Entrez le nombre initial de cellules vivantes : ");
//        Scanner sc = new Scanner(System.in);
//        while (!sc.hasNextInt()) {
//            System.out.println("Entrez le nombre initial de cellules vivantes : ");
//            sc.next();
//        }
//        int i = sc.nextInt();
//        return i;
//    }
//
//    @Override
//    public void update(int k) {
//        String a = "Generation : " + this.automate.getnbGeneration() + "\n";
//
//        for (int i = 0; i < hauteur; i++) {
//            for (int j = 0; j < largeur; j++) {
//                // System.out.println("Nombre de voisin de la cellule ("+i+ ","+j+ ") : "+ getNBcelluleVoisineVivante(tableau[i][j]) +
//                //       ", etat de la cellule : "+tableau[i][j].getEtat());              
//                if (this.automate.getCell(i, j).getEtat() == EtatCellule.VIVANTE) {
//                    a += "X|";
//                } else {
//                    a += " |";
//                }
//            }
//            a += "\n";
//        }
//        System.out.println(a);
//        choix();
//    }
//}
public class Vue {

    public static void main(String[] args) throws Exception {
        CelluleBl.delete();
        ConfigurationBl.delete();
        HistoriqueBl.delete();
//        SequenceDB.miseAZero(SequenceDB.CELLULE);
//        SequenceDB.miseAZero(SequenceDB.CONFIGURATION);
//        SequenceDB.miseAZero(SequenceDB.HISTORIQUE);

        SequenceDB.setSequenceInit();
        //        System.out.println(SequenceDB.getNextNum(SequenceDB.CELLULE));
        ConfigurationBl.add(new ConfigurationDto(100, 828, 26));
        ConfigurationBl.add(new ConfigurationDto(444, 3993, 288));
        ConfigurationBl.add(new ConfigurationDto(20, 100, 3637));
        HistoriqueBl.add(new HistoriqueDto(1, 2882, 388));
        HistoriqueBl.add(new HistoriqueDto(2, 2882, 388));
        HistoriqueBl.add(new HistoriqueDto(3, 2882, 388));
        CelluleBl.add(new CelluleDto(138, 38, true, 1, 1));
        CelluleBl.add(new CelluleDto(84, 38, false, 1, 1));
        CelluleBl.add(new CelluleDto(200, 0772, true, 2, 1));
//        ConfigurationBl.update(new ConfigurationDto(1, 39, 66, 7));
//        HistoriqueBl.update(new HistoriqueDto(1, 2, 78, 3));
        CelluleBl.update(new CelluleDto(3, 138, 38, false, 3, 1));
//        CelluleBl.delete();
//        ConfigurationBl.delete();
//        HistoriqueBl.delete();
//        SequenceDB.miseAZero(SequenceDB.CELLULE);
//        SequenceDB.miseAZero(SequenceDB.CONFIGURATION);
//        SequenceDB.miseAZero(SequenceDB.HISTORIQUE);
    }
}
