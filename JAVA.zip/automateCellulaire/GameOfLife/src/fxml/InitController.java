package fxml;

import business.CelluleBl;
import business.ConfigurationBl;
import business.HistoriqueBl;
import db.SequenceDB;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import modele.GameOfLife;
import modele.EtatCellule;
import modele.Facade;
import mycomponent.MyComponent;
import mycomponent.myComponentController;
import observer.Observer;
import persistence.dto.CelluleDto;
import persistence.dto.ConfigurationDto;
import persistence.dto.HistoriqueDto;

/**
 * Controller class
 *
 * @author shewolf
 */
public class InitController implements Observer {

    @FXML
    private ComboBox<String> combo1;

    @FXML
    private ComboBox<String> combo2;

    @FXML
    private ComboBox<String> combo3;

    @FXML
    private Button validate;

    private int hauteur;
    private int largeur;
    private int nbCell;

    private Facade automate;
    private MyComponent component;
    private myComponentController controller;

    private int idConfig;

    /**
     * Initializes the controller class.
     *
     * @throws java.sql.SQLException
     */
    public void initialize() throws Exception {
        CelluleBl.delete();
        ConfigurationBl.delete();
        HistoriqueBl.delete();
        SequenceDB.setSequenceInit();
    }

    public void fetchData() {
        hauteur = Integer.parseInt(combo1.getSelectionModel().selectedItemProperty().getValue());
        largeur = Integer.parseInt(combo2.getSelectionModel().selectedItemProperty().getValue());
        nbCell = Integer.parseInt(combo3.getSelectionModel().selectedItemProperty().getValue());
    }

    @FXML
    private void handleValidateButton(ActionEvent event) throws IOException, Exception {
        fetchData();

        Stage stage = (Stage) validate.getScene().getWindow();
        stage.close();
        if (nbCell > hauteur * largeur) {
            nbCell = hauteur * largeur;
        }
        //rajouter une config ds la bd
        this.idConfig = ConfigurationBl.add(new ConfigurationDto(hauteur, largeur, nbCell));

        component = new MyComponent();
        component.start(new Stage());
        controller = component.getCrtl();
        reset();
        update();
        HistoriqueBl.add(new HistoriqueDto(idConfig, automate.getnbGeneration(), nbCell));
        updateCellTab();

        controller.updateGrid(hauteur, largeur);

        controller.handleNextGeneration((ActionEvent event1) -> {
            updateDB();
        });

        controller.handleSkipGeneration((ActionEvent event1) -> {
            int generation = automate.getnbGeneration();
            for (int i = 0; i < controller.getTxtNb() - generation; i++) {
                updateDB();
            }
        });

        controller.handleConsulterGeneration((ActionEvent event1) -> {
            int value = controller.getValueSpinner();
            try {
                updatetwo(value);
            } catch (SQLException ex) {
                Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
            } catch (Exception ex) {
                Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });

        controller.handleResetButton((ActionEvent event1) -> {
            automate.deletteObserver(this);
            controller.clearPopulation();
            try {
                reset();
                update();
                initialize();
                this.idConfig = ConfigurationBl.add(new ConfigurationDto(hauteur, largeur, nbCell));
                HistoriqueBl.add(new HistoriqueDto(idConfig, automate.getnbGeneration(), nbCell));
                updateCellTab();
            } catch (Exception ex) {
                Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

    /**
     * ajoute une règle, met à jour le tableau ainsi que l'historique et la
     * table Cellule
     */
    public void updateDB() {
        automate.ajouterRegle();
        try {
            HistoriqueBl.add(new HistoriqueDto(idConfig,
                    this.automate.getnbGeneration(), automate.getNbRemainingCells()));
        } catch (Exception ex) {
            Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
        }
        updateCellTab();
    }

    public void reset() throws Exception {
        automate = new GameOfLife(hauteur, largeur, nbCell);
        automate.addObserver(this);
        controller.addInput(hauteur, largeur, nbCell);
    }

    @FXML
    private void handleQuitButton(ActionEvent event) {
        Platform.exit();
    }

    @Override
    public void update() {
        controller.clearGrid();
        for (int i = 0; i < hauteur; i++) {
            for (int j = 0; j < largeur; j++) {
                if (automate.getCellHistory(automate.getnbGeneration(), i, j)
                        .getEtat() == EtatCellule.VIVANTE) {
                    Circle circle = new Circle();
                    circle.setRadius(3);
                    circle.setFill(Color.BLACK);
                    GridPane.setHalignment(circle, HPos.CENTER);
                    GridPane.setValignment(circle, VPos.CENTER);
                    controller.update(circle, i, j);
                }

                controller.addPopulation("ALIVE",
                        automate.getnbGeneration(), automate.getNbRemainingCells(),
                        automate.getPercentageRemainingCells());
                controller.addPopulation("DEAD", automate.getnbGeneration(),
                        hauteur * largeur - automate.getNbRemainingCells(),
                        100 - automate.getPercentageRemainingCells());

            }
        }
    }

    /**
     * Met à jour la table Cellule
     */
    public void updateCellTab() {
        for (int i = 0; i < hauteur; i++) {
            for (int j = 0; j < largeur; j++) {
//                if (automate.getnbGeneration() == 0) {
                try {
                    //rajouter chaque cellule ds la bd
                    CelluleBl.add(new CelluleDto(i, j,
                            automate.getCellHistory(automate.getnbGeneration(), i, j)
                                    .getEtat() == EtatCellule.VIVANTE,
                            automate.getnbGeneration(), idConfig
                    ));
                } catch (Exception ex) {
                    Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
                }
//                } else {
//                    try {
//                        CelluleBl.update(new CelluleDto(i, j,
//                                automate.getCellHistory(automate.getnbGeneration(), i, j)
//                                        .getEtat() == EtatCellule.VIVANTE,
//                                automate.getnbGeneration(), idConfig
//                        ));
//                    } catch (Exception ex) {
//                        Logger.getLogger(InitController.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                }
            }
        }
    }

    /**
     * Récupère les cellules de la generation 'generation' et met à jour le
     * tableau avec les nouvelles cellules
     *
     * @param generation la génération désirée
     * @throws Exception
     */
    public void updatetwo(int generation) throws Exception {
        ArrayList<CelluleDto> listeCell = (ArrayList<CelluleDto>) CelluleBl.findAllColletions(generation);

        controller.clearGrid();

        for (int i = 0; i < listeCell.size(); i++) {

            if (listeCell.get(i).getEtat() == true) {
                Circle circle = new Circle();
                circle.setRadius(3);
                circle.setFill(Color.BLACK);
                GridPane.setHalignment(circle, HPos.CENTER);
                GridPane.setValignment(circle, VPos.CENTER);
                controller.update(circle, listeCell.get(i).getX(), listeCell.get(i).getY());
            }
        }
    }

}
