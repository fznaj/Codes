package modele;

/**
 * Represente une position de l'automate x -> represente une ligne de l'automate
 * y -> represente une colonne de l'automate
 *
 * @author bilal
 */
public class Position {

    private int x;
    private int y;

    /**
     *
     * @param x
     * @param y
     */
    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     *
     * @return
     */
    public int getX() {
        return this.x;
    }

    /**
     *
     * @return
     */
    public int getY() {
        return this.y;
    }

    public static Position getDown(Cellule cell) {
        return new Position(cell.getPosition().getX() + 1, cell.getPosition().getY());
    }

    public static Position getUp(Cellule cell) {
        return new Position(cell.getPosition().getX() - 1, cell.getPosition().getY());
    }

    public static Position getLeft(Cellule cell) {
        return new Position(cell.getPosition().getX(), cell.getPosition().getY() - 1);
    }

    public static Position getRight(Cellule cell) {
        return new Position(cell.getPosition().getX(), cell.getPosition().getY() + 1);
    }

    public static Position getUpLeft(Cellule cell) {
        return new Position(cell.getPosition().getX() - 1, cell.getPosition().getY() - 1);
    }

    public static Position getUpRight(Cellule cell) {
        return new Position(cell.getPosition().getX() - 1, cell.getPosition().getY() + 1);
    }

    public static Position getDownLeft(Cellule cell) {
        return new Position(cell.getPosition().getX() + 1, cell.getPosition().getY() - 1);
    }

    public static Position getDownRight(Cellule cell) {
        return new Position(cell.getPosition().getX() + 1, cell.getPosition().getY() + 1);
    }
}
