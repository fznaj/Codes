package modele;

public class Regle3 extends Regle {

    @Override
    public void regle(Cellule cell, Cellule[][] tableau, Cellule[][] tableau2) {
        if (getNBcelluleVoisineVivante(cell, tableau) == 2) {
            tableau2[cell.getPosition().getX()][cell.getPosition().getY()] = cell;
        }
    }
}
