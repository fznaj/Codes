package modele;

/**
 * Cette classe represente la 2ème régle qu'on applique à l'automate
 *
 * @author bilal
 */
public class Regle2 extends Regle {

    @Override
    public void regle(Cellule cell, Cellule[][] tableau, Cellule[][] tableau2) {
        if (getNBcelluleVoisineVivante(cell, tableau) > 3 || getNBcelluleVoisineVivante(cell, tableau) < 2) {
            cell.setEtat(EtatCellule.MORTE);
            tableau2[cell.getPosition().getX()][cell.getPosition().getY()] = cell;
        }
    }
}
