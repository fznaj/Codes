package modele;

import java.util.ArrayList;
import java.util.List;

/**
 * Représente une celle : position, état et ancien état
 *
 * @author shewolf
 */
public class Cellule {

    private Position pos; // coordonées de la cellule dans l'automate
    private EtatCellule etat; // état de la cellule, true si occupée
    private List<EtatCellule> ancienEtat; //état de la cellule à la génération précédente

    /**
     * Constructeur
     *
     * @param pos position de la cellule sur le tableau
     * @param etat l'état de la cellule
     */
    public Cellule(Position pos, EtatCellule etat) {
        this.ancienEtat = new ArrayList();
        this.pos = pos;
        this.etat = etat;
    }

    /**
     * change l'état de la cellule
     *
     * @param nvlEtat le nouvel état
     */
    public void setEtat(EtatCellule nvlEtat) {
        ancienEtat.add(etat);
        this.etat = nvlEtat;
    }

    /**
     *
     * @return la position de la cellule
     */
    public Position getPosition() {
        return this.pos;
    }

    /**
     *
     * @return l'état de la cellule
     */
    public EtatCellule getEtat() {
        return this.etat;
    }

}
