package modele;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bilal
 */
public class Historique {

    private final List<Cellule[][]> historique;

    public Historique() {
        historique = new ArrayList();
    }

    public void addTableau(Cellule[][] tab) {
        historique.add(tab);
    }

    public Cellule[][] getTabAt(int i) {
        return historique.get(i);
    }
}
