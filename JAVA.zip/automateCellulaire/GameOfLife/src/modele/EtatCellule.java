package modele;

/**
 * Enumeration des états possibles d'une cellule
 *
 * @author bilal
 */
public enum EtatCellule {

    VIVANTE,
    MORTE;
}
