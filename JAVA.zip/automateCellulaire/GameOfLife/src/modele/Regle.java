package modele;

/**
 * cette interface va nous permettre d'implementer le desgin pattern strategy
 * chaque regle sera representer par une classe
 *
 * @author bilal
 */
public abstract class Regle {

    public abstract void regle(Cellule cell, Cellule[][] tableau, Cellule[][] tableau2);

    /**
     * retourne le nombre de cellules voisines vivantes de la cellule cell
     *
     * @param cell cellule courante
     * @param tableau tableau de Cellule
     * @return entier représentant le nombre de cellules voisines vivantes
     */
    protected int getNBcelluleVoisineVivante(Cellule cell, Cellule[][] tableau) {

        int cpt = 0;
        Position pos;

        //haut y le meme, x-1
        pos = Position.getUp(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //bas y le meme, x+1
        pos = Position.getDown(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //gauche x le meme, y-1
        pos = Position.getLeft(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //droite x le meme, y+1
        pos = Position.getRight(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //diagonale haut gauche
        pos = Position.getUpLeft(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //diagonale haut droit
        pos = Position.getUpRight(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //diagonale bas gauche
        pos = Position.getDownLeft(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        //diagonale bas droite
        pos = Position.getDownRight(cell);
        if (positionValide(pos, tableau)) {
            if (tableau[pos.getX()][pos.getY()].getEtat() == EtatCellule.VIVANTE) {
                cpt++;
            }
        }

        return cpt;
    }

    //return vrai si la pos est ds le plateau faux sinon.
    private boolean positionValide(Position pos, Cellule[][] tableau) {
        return ((pos.getX() >= 0) && (pos.getX() < tableau.length)
                && (pos.getY() >= 0) && (pos.getY() < tableau[0].length));
    }
}
