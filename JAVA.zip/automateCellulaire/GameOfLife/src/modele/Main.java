package modele;

//import vue.Vue;
/**
 *
 * @author bilal
 */
public class Main {

    public static void main(String[] args) {

//        Vue vue = new Vue();
    }
}
