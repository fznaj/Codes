package modele;

import java.util.ArrayList;
import java.util.List;
import observer.Observable;
import observer.Observer;

/**
 * classe qui représente l'automate cellulaire
 *
 * @author shewolf
 */
public class GameOfLife implements Observable, Facade {

    private Cellule[][] tableau;
    private final int largeur;
    private final int hauteur;
    private final int nbCelluleVivante;
    private int nbGeneration;
    private final List<Observer> obsrvs;
    private final List<Regle> regles;
    //private int lastGeneration = 100;
    private final Historique historique;

    /**
     * Constructeur
     *
     * @param hauteur l'hauteur du tableau
     * @param largeur largeur du tableau
     * @param nbCellule nombre de cellules vivantes initiales
     */
    public GameOfLife(int hauteur, int largeur, int nbCellule) {

        this.nbGeneration = 0;
        this.nbCelluleVivante = nbCellule;
        this.hauteur = hauteur;
        this.largeur = largeur;
        this.obsrvs = new ArrayList();
        this.tableau = new Cellule[hauteur][largeur];
        regles = new ArrayList();
        historique = new Historique();
        for (int x = 0; x < nbCelluleVivante; x++) {
            int k = aleatoire(0, this.hauteur - 1);
            int p = aleatoire(0, this.largeur - 1);
            this.tableau[k][p] = new Cellule(new Position(k, p), EtatCellule.VIVANTE);
        }

        for (int i = 0; i < this.hauteur; i++) {
            for (int j = 0; j < this.largeur; j++) {
                if (this.tableau[i][j] == null) {
                    this.tableau[i][j] = new Cellule(new Position(i, j), EtatCellule.MORTE);
                }
            }
        }
        historique.addTableau(tableau);
    }

    /**
     *
     * @param min
     * @param max
     * @return genere un nombre aleatoire entre min et max
     */
    private int aleatoire(int min, int max) {
        int range = (max - min) + 1;
        return (int) (Math.random() * range) + min;
    }

    /**
     * ajoute les regles du jeu et les applique automatiquement à l'automate
     */
    @Override
    public void ajouterRegle() {
        if (!isOver()) {
            regles.add(new Regle1());
            regles.add(new Regle2());
            regles.add(new Regle3());

            Cellule[][] tableau2 = new Cellule[hauteur][largeur];

            for (int k = 0; k < hauteur; k++) {
                for (int j = 0; j < largeur; j++) {
                    for (int i = 0; i < regles.size(); i++) {
                        regles.get(i).regle(this.tableau[k][j], this.tableau, tableau2);
                    }
                }
            }
            this.nbGeneration++;
            tableau = tableau2;
            historique.addTableau(tableau);
            notifyObservers();
        }
    }

    public boolean isOver() {
        return getNbRemainingCells() == 0;
    }

    @Override
    public void skipTo(int generation) {
//        lastGeneration = generation;
        for (int i = 0; i < generation - nbGeneration; i++) {
            ajouterRegle();
        }
    }

    /**
     * retourne une copie du tableau de cellules
     *
     * @param i
     * @return un tableau de Cellule
     */
    @Override
    public Cellule[][] getTableau(int i) {
//        Cellule[][] tab = new Cellule[hauteur][largeur];
//        for (int k = 0; k < hauteur; k++) {
//            for (int j = 0; j < largeur; j++) {
//                tab[k][j] = new Cellule(tableau[k][j].getPosition(), tableau[k][j].getEtat());
//            }
//        }
//        return tab;
        return historique.getTabAt(i);
    }

    @Override
    public Cellule getCell(int i, int j) {
        return tableau[i][j];
    }

    @Override
    public Cellule getCellHistory(int i, int j, int k) {
        return historique.getTabAt(i)[j][k];
    }

    @Override
    public int getNbRemainingCells() {
        int nb = 0;
        for (int i = 0; i < hauteur; i++) {
            for (int j = 0; j < largeur; j++) {
                if (getCell(i, j).getEtat() == EtatCellule.VIVANTE) {
                    nb++;
                }
            }
        }
        return nb;
    }

    @Override
    public int getPercentageRemainingCells() {
        return getnbGeneration() == 0 ? (nbCelluleVivante * 100) / (hauteur * largeur)
                : (getNbRemainingCells() * 100) / (hauteur * largeur);
    }

    /**
     * getter du numéro de la génération
     *
     * @return integer représentant le numéro de la génération
     */
    @Override
    public int getnbGeneration() {
        return this.nbGeneration;
    }

    /**
     * ajoute un observer
     *
     * @param o Observer
     */
    @Override
    public void addObserver(Observer o) {
        this.obsrvs.add(o);
    }

    /**
     * supprime un observer de la liste
     *
     * @param o Observer
     */
    @Override
    public void deletteObserver(Observer o) {
        if (obsrvs.contains(o)) {
            obsrvs.remove(o);
        }
    }

    /**
     * notifie tous les observers ajoutés et les met à jour
     *
     */
    @Override
    public void notifyObservers() {
        for (int nb = 0; nb < this.obsrvs.size(); nb++) {
            this.obsrvs.get(nb).update();
        }
    }
}
