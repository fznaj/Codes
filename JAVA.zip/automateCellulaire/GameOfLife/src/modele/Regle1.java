package modele;

/**
 * Cette classe represente la premiere règle qu'on applique a l'automate
 *
 * @author bilal
 */
public class Regle1 extends Regle {

    @Override
    public void regle(Cellule cell, Cellule[][] tableau, Cellule[][] tableau2) {

        if (getNBcelluleVoisineVivante(cell, tableau) == 3) {
            cell.setEtat(EtatCellule.VIVANTE);
            tableau2[cell.getPosition().getX()][cell.getPosition().getY()] = cell;
        }
    }
}
