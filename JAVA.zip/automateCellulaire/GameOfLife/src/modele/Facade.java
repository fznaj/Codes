package modele;

import observer.Observer;

/**
 *
 * @author G39986
 *
 * interface facade
 */
public interface Facade {

    /**
     * retourne une copie du tableau de cellules
     *
     * @param i
     * @return un tableau de Cellule
     */
    public Cellule[][] getTableau(int i);

    /**
     * getter du numéro de la génération
     *
     * @return integer représentant le numéro de la génération
     */
    public int getnbGeneration();

    /**
     * ajoute les regles du jeu et les applique automatiquement à l'automate
     */
    public void ajouterRegle();

    public Cellule getCell(int i, int j);

    public int getNbRemainingCells();

    public void addObserver(Observer obs);

    public int getPercentageRemainingCells();

    public Cellule getCellHistory(int i, int j, int k);

    public void skipTo(int generation);

    public void deletteObserver(Observer o);

}
