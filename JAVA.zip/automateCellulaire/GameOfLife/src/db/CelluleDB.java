package db;

import java.util.ArrayList;
import java.util.List;
import persistence.dto.CelluleDto;
import java.sql.SQLException;
import selDto.CelluleSel;

/**
 *
 * @author G39986
 */
public class CelluleDB {

    public static List<CelluleDto> getAllCellule() throws SQLException, Exception {
        List<CelluleDto> cellules = getCollection(new CelluleSel(0));
        return cellules;
    }

    public static List<CelluleDto> getCollection(CelluleSel sel) throws SQLException, Exception {

        List<CelluleDto> al = new ArrayList<>();
        try {
            String query = "Select id, x, y,etat,idGeneration, idConfig  FROM Cellule";
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement stmt;

            String where = "";
            if (sel.getId() != 0) {
                where = where + " id = ? ";
            }
            if (sel.getX() != 0) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " x = ? ";
            }
            if (sel.getY() != 0) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " y = ? ";
            }
            if (sel.getidGeneration() != 0) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " idGeneration = ?, ";
            }
            if (sel.getIdConf() != 0) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " idConfig = ? ";
            }

            if (sel.getActive() != null) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " etat = ? ";
            }

            if (where.length() != 0) {
                where = " where " + where + " order by name, firstName";
                query = query + where;
                stmt = connexion.prepareStatement(query);
                int i = 1;
                if (sel.getId() != 0) {
                    stmt.setInt(i, sel.getId());
                    i++;
                }

                if (sel.getX() != 0) {
                    stmt.setString(i, sel.getX() + "%");
                    i++;
                }
                if (sel.getY() != 0) {
                    stmt.setString(i, sel.getY() + "%");
                    i++;
                }
                if (sel.getidGeneration() != 0) {
                    stmt.setString(i, sel.getidGeneration() + "%");
                    i++;
                }

                if (sel.getIdConf() != 0) {
                    stmt.setString(i, sel.getIdConf() + "%");
                    i++;
                }

                if (sel.getActive() != null) {
                    stmt.setString(i, sel.getActive() ? "1" : "0");
                    i++;
                }
            } else {
                query = query + " Order by name, firstName";
                stmt = connexion.prepareStatement(query);
            }

            java.sql.ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                al.add(new CelluleDto(rs.getInt("id"), rs.getInt("x"),
                        rs.getInt("y"), rs.getBoolean("etat"),
                        rs.getInt("idGeneration"), rs.getInt("idConfig")));
            }
        } catch (Exception ex) {
            throw new Exception("Instanciation de Cellule impossible:\nDTOException: " + ex.getMessage());
        }
        return al;
    }

    /**
     * Supprime une cellule de la base de données
     *
     * @param id l'id de la cellule
     * @throws Exception
     */
    public static void deleteDb(int id) throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Cellule where id=" + id);
        } catch (Exception ex) {
            throw new Exception("Suppression Cellule impossible\n" + ex.getMessage());
        }
    }

    /**
     * Met à jour une cellule de la base de données
     *
     * @param cli la cellule
     * @throws SQLException
     * @throws Exception
     */
    public static void updateDb(CelluleDto cli) throws SQLException, Exception {
        try {
            java.sql.Connection connexion = DBManager.getConnection();

            java.sql.PreparedStatement update;
//            String sql = "Update Cellule set "
//                    + "x=?, "
//                    + "y=?, "
//                    + "etat =?, "
//                    + "idConfig=? "
//                    + "where id=?";
            String sql = "Update Cellule set "
                    + "etat =?, "
                    + "idGeneration=?, "
                    + "idConfig=? "
                    + "where x=? AND y=?";
            update = connexion.prepareStatement(sql);

//            update.setInt(1, cli.getX());
//            update.setInt(2, cli.getY());
            update.setBoolean(1, cli.getEtat());
            update.setInt(2, cli.getIdGen());
            update.setInt(3, cli.getIdConfig());
            update.setInt(4, cli.getX());
            update.setInt(5, cli.getY());
            update.executeUpdate();
        } catch (Exception ex) {
            throw new Exception("Cellule modification impossible:\n" + ex.getMessage());
        }
    }

    /**
     * Insère une cellule dans la base de données
     *
     * @param cli la cellule à insérer
     * @return le numéro de séquence (id) de la cellule
     * @throws Exception
     */
    public static int insertDb(CelluleDto cli) throws Exception {
        try {
            int num = SequenceDB.getNextNum(SequenceDB.CELLULE);
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement insert;
            insert = connexion.prepareStatement(
                    "Insert into Cellule(id, x, y,etat,idGeneration, idConfig) "
                    + "values(?, ?, ?,?,?,? )");

            insert.setInt(1, num);
            insert.setInt(2, cli.getX());
            insert.setInt(3, cli.getY());
            insert.setBoolean(4, cli.getEtat());
            insert.setInt(5, cli.getIdGen());
            insert.setInt(6, cli.getIdConfig());

            insert.executeUpdate();
            return num;
        } catch (SQLException ex) {
            throw new Exception("Cellule : ajout impossible\n" + ex.getMessage());
        }
    }

    /**
     * retourne une liste de cellule dont l'idGeneration est idGen
     *
     * @param idGen l'id de génération
     * @return une liste de cellule
     * @throws SQLException
     * @throws Exception
     */
    public static List<CelluleDto> getCellulesByGeneration(int idGen) throws SQLException, Exception {
        List<CelluleDto> al = new ArrayList<>();

        java.sql.Connection connexion = DBManager.getConnection();

        java.sql.PreparedStatement select;
        String sql = "Select * from Cellule where idGeneration = ? ";

        select = connexion.prepareStatement(sql);

        select.setInt(1, idGen);

        java.sql.ResultSet rs = select.executeQuery();

        while (rs.next()) {
            al.add(new CelluleDto(rs.getInt("id"), rs.getInt("x"),
                    rs.getInt("y"), rs.getBoolean("etat"),
                    rs.getInt("idGeneration"), rs.getInt("idConfig")));
        }
        return al;
    }

    /**
     * Vide la table Cellule
     *
     * @throws Exception
     */
    public static void deleteCellules() throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Cellule");
        } catch (Exception ex) {
            throw new Exception("Cellule suppression impossible\n" + ex.getMessage());
        }
    }
}
