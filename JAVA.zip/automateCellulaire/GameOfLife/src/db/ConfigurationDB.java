package db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import persistence.dto.ConfigurationDto;
import selDto.ConfigurationSel;

/**
 *
 * @author G39986
 */
public class ConfigurationDB {

    public static List<ConfigurationDto> getAllCellule() throws SQLException, Exception {
        List<ConfigurationDto> configurations = getCollection(new ConfigurationSel(0));
        return configurations;
    }

    public static List<ConfigurationDto> getCollection(ConfigurationSel sel) throws SQLException, Exception {
        List<ConfigurationDto> al = new ArrayList<>();
        try {
            String query = "Select id, largeur, hauteur, nbCellvivanteDepart FROM Configuration";
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement stmt;

            String where = "";
            if (sel.getId() != 0) {
                where = where + " id = ? ";
            }

            if (sel.getHauteur() != 0) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " hauteur = ? ";
            }
            if (sel.getLargeur() != 0) {
                if (!where.isEmpty()) {
                    where = where + " AND ";
                }
                where = where + " largeur = ? ";
            }

            if (sel.getnbCellvivanteDepart() != 0) {
                if (!where.isEmpty()) {
                    where = where + " AND ";
                }
                where = where + " nbCellvivanteDepart = ? ";
            }

            if (sel.getActive() != null) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " active = ? ";
            }

            if (where.length() != 0) {
                where = " where " + where + " order by name, firstName";
                query = query + where;
                stmt = connexion.prepareStatement(query);
                int i = 1;
                if (sel.getId() != 0) {
                    stmt.setInt(i, sel.getId());
                    i++;

                }
                if (sel.getHauteur() != 0) {
                    stmt.setString(i, sel.getHauteur() + "%");
                    i++;
                }
                if (sel.getLargeur() != 0) {
                    stmt.setString(i, sel.getLargeur() + "%");
                    i++;
                }
                if (sel.getnbCellvivanteDepart() != 0) {
                    stmt.setString(i, sel.getnbCellvivanteDepart() + "%");
                    i++;
                }
                if (sel.getActive() != null) {
                    stmt.setString(i, sel.getActive() ? "1" : "0");
                    i++;
                }
            } else {
                query = query + " Order by name, firstName";
                stmt = connexion.prepareStatement(query);
            }

            java.sql.ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                al.add(new ConfigurationDto(rs.getInt("id"), rs.getInt("largeur"),
                        rs.getInt("hauteur"), rs.getInt("nbCellvivanteDepart")));
            }
        } catch (SQLException ex) {
            throw new Exception("Instanciation de Cofnfig impossible:\nDTOException: " + ex.getMessage());
        }
        return al;
    }

    /**
     * Supprime une config de la base de données
     *
     * @param id l'id de la config
     * @throws Exception
     */
    public static void deleteDb(int id) throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Configuration where id=" + id);
        } catch (Exception ex) {
            throw new Exception("Config: suppression impossible\n" + ex.getMessage());
        }
    }

    /**
     * Met à jour une config
     *
     * @param cli la config à mettre à jour
     * @throws SQLException
     * @throws Exception
     */
    public static void updateDb(ConfigurationDto cli) throws SQLException, Exception {
        try {
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement update;
            String sql = "Update Configuration set "
                    + "largeur=?, "
                    + "hauteur=?, "
                    + "nbCellvivanteDepart=? "
                    + "where id=?";
            update = connexion.prepareStatement(sql);

            update.setInt(1, cli.getLargeur());
            update.setInt(2, cli.getHauteur());
            update.setInt(3, cli.getnbCellvivanteDepart());
            update.setInt(4, cli.getId());
            update.executeUpdate();
        } catch (SQLException ex) {
            throw new Exception("Config, modification impossible:\n" + ex.getMessage());
        }
    }

    /**
     * Insère une config dans la base de données
     *
     * @param cli la config à insérer
     * @return l'id de la config
     * @throws Exception
     */
    public static int insertDb(ConfigurationDto cli) throws Exception {

        try {
            int num = SequenceDB.getNextNum(SequenceDB.CONFIGURATION);
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement insert;
            insert = connexion.prepareStatement(
                    "Insert into Configuration(id, largeur, hauteur, nbCellvivanteDepart) "
                    + "values(?, ?, ?,? )");
            insert.setInt(1, num);
            insert.setInt(3, cli.getLargeur());
            insert.setInt(2, cli.getHauteur());
            insert.setInt(4, cli.getnbCellvivanteDepart());

            insert.executeUpdate();
            return num;
        } catch (Exception ex) {
            throw new Exception("Config: ajout impossible\n" + ex.getMessage());
        }
    }

    /**
     * Vide la table Configuration
     *
     * @throws Exception
     */
    public static void deleteConfigurations() throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Configuration");
        } catch (Exception ex) {
            throw new Exception("Client: suppression impossible\n" + ex.getMessage());
        }
    }
}
