package db;

import java.sql.SQLException;

/**
 * Classe d'accès au gestionnaire de persistance pour les Séquences
 */
public class SequenceDB {

    public static final String CELLULE = "Cellule";
    public static final String HISTORIQUE = "Historique";
    public static final String CONFIGURATION = "Configuration";

    /**
     * Vide la table Sequence et insère les nouvelle valeur d'initialisation : 0
     * pour chaque table
     *
     * @throws Exception
     */
    public static void setSequenceInit() throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Sequence");
            stmt.execute("Insert into SEQUENCE VALUES(0,'Configuration')");
            stmt.execute("Insert into SEQUENCE VALUES(0,'Historique')");
            stmt.execute("Insert into SEQUENCE VALUES(0,'Cellule')");
        } catch (java.sql.SQLException eSQL) {
            throw new Exception("can't add initial values" + eSQL.getMessage());
        }
    }

    public static synchronized int getNextNum(String sequence) throws Exception {
        try {
            java.sql.Connection connexion = DBManager.getConnection();
            String query = "Update SEQUENCE set sValue = sValue+1 where id='" + sequence + "'";
            java.sql.PreparedStatement update = connexion.prepareStatement(query);
            update.execute();
            java.sql.Statement stmt = connexion.createStatement();
            query = "Select sValue FROM Sequence where id='" + sequence + "'";
            java.sql.ResultSet rs = stmt.executeQuery(query);
            int nvId;
            if (rs.next()) {
                nvId = rs.getInt("sValue");
                return nvId;
            } else {
                nvId = 1;
                return nvId;
            }
        } catch (java.sql.SQLException eSQL) {
            throw new Exception("Nouveau n° de séquence inaccessible!\n" + eSQL.getMessage());
        }
    }

    /**
     * Remet les compteurs à 0
     *
     * @param id le nom de la table
     * @throws SQLException
     * @throws Exception
     */
    public static void miseAZero(String id) throws SQLException, Exception {

        java.sql.Connection connexion = DBManager.getConnection();
        java.sql.PreparedStatement insert;
        insert = connexion.prepareStatement("Update SEQUENCE set sValue = ? where id= ? ");
        insert.setInt(1, 0);
        insert.setString(2, id);
        insert.executeUpdate();
//        try {
//            java.sql.Statement stmt = DBManager.getConnection().createStatement();
//            stmt.execute("Delete from Sequence");
//            System.out.println("done");
//        } catch (Exception ex) {
//            throw new Exception("blabla: suppression impossible\n" + ex.getMessage());
//        }
    }
}
