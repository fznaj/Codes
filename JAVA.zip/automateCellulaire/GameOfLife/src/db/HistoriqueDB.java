package db;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import persistence.dto.HistoriqueDto;
import selDto.HistoriqueSel;

/**
 *
 * @author G39986
 */
public class HistoriqueDB {

    public static List<HistoriqueDto> getAllCellule() throws SQLException, Exception {
        List<HistoriqueDto> cellules = getCollection(new HistoriqueSel(0));
        return cellules;
    }

    public static List<HistoriqueDto> getCollection(HistoriqueSel sel) throws SQLException, Exception {
        List<HistoriqueDto> al = new ArrayList<>();
        try {
            String query = "Select id, idConfig, generation, nbCell FROM Historique";

            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement stmt;

            String where = "";
            if (sel.getId() != 0) {
                where = where + " id = ? ";
            }
            if (sel.getidConfig() != 0) {
                if (!where.isEmpty()) {
                    where = where + " AND ";
                }
                where = where + " idConfig = ? ";
            }

            if (sel.getGeneration() != 0) {
                if (!where.isEmpty()) {
                    where = where + " AND ";
                }
                where = where + " generation = ? ";
            }

            if (sel.getNbCellDepart() != 0) {
                if (!where.isEmpty()) {
                    where = where + " AND ";
                }
                where = where + " nbCell = ? ";
            }
            if (sel.getActive() != null) {
                if (!where.equals("")) {
                    where = where + " AND ";
                }
                where = where + " active = ? ";
            }

            if (where.length() != 0) {
                where = " where " + where + " order by name, firstName";
                query = query + where;
                stmt = connexion.prepareStatement(query);
                int i = 1;
                if (sel.getId() != 0) {
                    stmt.setInt(i, sel.getId());
                    i++;

                }
                if (sel.getidConfig() != 0) {
                    stmt.setString(i, sel.getidConfig() + "%");
                    i++;
                }
                if (sel.getGeneration() != 0) {
                    stmt.setString(i, sel.getGeneration() + "%");
                    i++;
                }
                if (sel.getNbCellDepart() != 0) {
                    stmt.setString(i, sel.getNbCellDepart() + "%");
                    i++;
                }

                if (sel.getActive() != null) {
                    stmt.setString(i, sel.getActive() ? "1" : "0");
                    i++;
                }
            } else {
                query = query + " Order by name, firstName";
                stmt = connexion.prepareStatement(query);
            }

            java.sql.ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                al.add(new HistoriqueDto(rs.getInt("id"), rs.getInt("idConfig"),
                        rs.getInt("generation"), rs.getInt("nbCell")));
            }
        } catch (Exception ex) {
            throw new Exception("Instanciation d'historique impossible:\nDTOException: " + ex.getMessage());
        }
        return al;
    }

    /**
     * Supprime un historique de la base de données
     *
     * @param id l'id
     * @throws Exception
     */
    public static void deleteDb(int id) throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Historique where id=" + id);
        } catch (Exception ex) {
            throw new Exception("suppression historique impossible\n" + ex.getMessage());
        }
    }

    /**
     * Met à jour l'historique
     *
     * @param cli l'id de l'historique
     * @throws SQLException
     * @throws Exception
     */
    public static void updateDb(HistoriqueDto cli) throws SQLException, Exception {
        try {
            java.sql.Connection connexion = DBManager.getConnection();

            java.sql.PreparedStatement update;
            String sql = "Update Historique set "
                    + "idConfig=?,"
                    + "generation=?, "
                    + "nbCell=? "
                    + "where id=?";
            update = connexion.prepareStatement(sql);

            update.setInt(1, cli.getIdConfig());
            update.setInt(2, cli.getGeneration());
            update.setInt(3, cli.getNbCellDepart());
            update.setInt(4, cli.getId());
            update.executeUpdate();
        } catch (Exception ex) {
            throw new Exception("Historique modification impossible:\n" + ex.getMessage());
        }
    }

    /**
     * Insère un historique dans la base de données
     *
     * @param cli l'historique à insérer
     * @return l'id de l'historique inséré
     * @throws Exception
     */
    public static int insertDb(HistoriqueDto cli) throws Exception {
        try {
            int num = SequenceDB.getNextNum(SequenceDB.HISTORIQUE);
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement insert;
            insert = connexion.prepareStatement(
                    "Insert into Historique(id,idConfig, generation, nbCell) "
                    + "values(?, ?, ?,?)");
            insert.setInt(1, num);
            insert.setInt(2, cli.getIdConfig());
            insert.setInt(3, cli.getGeneration());
            insert.setInt(4, cli.getNbCellDepart());

            insert.executeUpdate();
            return num;
        } catch (SQLException ex) {
            throw new Exception("Historique : ajout impossible\n" + ex.getMessage());
        }
    }

    public static void setactive(int id, boolean b) {
        try {
            java.sql.Connection connexion = DBManager.getConnection();
            java.sql.PreparedStatement update;
            update = connexion.prepareStatement("Update Client set "
                    + " active=?"
                    + "where id= ?");
            update.setString(1, b ? "1" : "0");
            update.setInt(2, id);
            update.executeUpdate();
        } catch (Exception ex) {
            //  throw new EsaleDbException("Commande, notification de 'traitée' impossible:\n" + ex.getMessage());
        }
    }

    /**
     * Vide la table Cellule
     *
     * @throws Exception
     */
    public static void deleteHistoriques() throws Exception {
        try {
            java.sql.Statement stmt = DBManager.getConnection().createStatement();
            stmt.execute("Delete from Historique");
        } catch (Exception ex) {
            throw new Exception("Historique: suppression impossible\n" + ex.getMessage());
        }
    }
}
