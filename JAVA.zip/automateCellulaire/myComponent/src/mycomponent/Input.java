package mycomponent;

import javafx.beans.property.SimpleIntegerProperty;

/**
 *
 * @author shewolf
 */
public class Input {

    private SimpleIntegerProperty length;
    private SimpleIntegerProperty width;
    private SimpleIntegerProperty nbCellsInit;

    public Input() {
        this(0, 0, 0);
    }

    public Input(int length, int width, int nbCellsInit) {
        this.length = new SimpleIntegerProperty(length);
        this.width = new SimpleIntegerProperty(width);
        this.nbCellsInit = new SimpleIntegerProperty(nbCellsInit);
    }

    public SimpleIntegerProperty getLengthProp() {
        return length;
    }

    public SimpleIntegerProperty getWidthProp() {
        return width;
    }

    public SimpleIntegerProperty getNbCellsInitProp() {
        return nbCellsInit;
    }

    public void setLength(int length) {
        this.length.set(length);
    }

    public void setWidth(int width) {
        this.width.set(width);
    }

    public void setNbCellsInit(int nbCellsInit) {
        this.nbCellsInit.set(nbCellsInit);
    }

    public int getLength() {
        return length.get();
    }

    public int getWidth() {
        return width.get();
    }

    public int getNbCellsInit() {
        return nbCellsInit.get();
    }
}
