package mycomponent;

import java.io.IOException;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author G42726
 */
public class myComponentController extends BorderPane {

    private final SimpleStringProperty nameProp;
    private final SimpleIntegerProperty lengthProp;
    private final SimpleIntegerProperty widthProp;
    private final SimpleIntegerProperty nbCellsProp;
    private final SimpleIntegerProperty generationProperty;
    private final SimpleIntegerProperty nbRemainingCellsProperty;
    private final SimpleDoubleProperty percentageRemainingCellsProperty;

    @FXML
    private TableView<Input> inputTable;

    @FXML
    private TableView<Population> outputTable;

    @FXML
    private TableColumn<Population, String> name;

    @FXML
    private TableColumn<Input, Integer> lengthInit;

    @FXML
    private TableColumn<Input, Integer> widthInit;

    @FXML
    private TableColumn<Input, Integer> cellsInit;

    @FXML
    private TableColumn<Population, Integer> nbGeneration;

    @FXML
    private TableColumn<Population, Integer> number;

    @FXML
    private TableColumn<Population, Double> cellsPercentage;

    private ObservableList<Input> listInput;
    private ObservableList<Population> listOutput;

    @FXML
    private Button nextG;

    @FXML
    private Button btn;

    @FXML
    private Button skipG;

    @FXML
    private Button reset;

    @FXML
    private GridPane gpane;

    @FXML
    private ProgressBar progressBar;

    @FXML
    private TextField txtNb;

    @FXML
    private Spinner spinner;

    public void initialize() {
        listInput = FXCollections.observableArrayList();
        inputTable.setItems(listInput);
        listOutput = FXCollections.observableArrayList();
        outputTable.setItems(listOutput);

        lengthInit.setCellValueFactory(new PropertyValueFactory<>("Length"));
        widthInit.setCellValueFactory(new PropertyValueFactory<>("Width"));
        cellsInit.setCellValueFactory(new PropertyValueFactory<>("nbCellsInit"));
        name.setCellValueFactory(new PropertyValueFactory<>("Name"));
        number.setCellValueFactory(new PropertyValueFactory<>("nbCellsAlive"));
        nbGeneration.setCellValueFactory(new PropertyValueFactory<>("Generation"));
        cellsPercentage.setCellValueFactory(new PropertyValueFactory<>("Proportion"));

        nbRemCellsProp().addListener((ObservableValue<? extends Number> observable, Number oldValue, Number newValue) -> {
            progressBar.setProgress((double) getPercentage() / getNbCells());
        });
    }

    public myComponentController() throws IOException {
        lengthProp = new SimpleIntegerProperty(0);
        widthProp = new SimpleIntegerProperty(0);
        nbCellsProp = new SimpleIntegerProperty(0);

        nameProp = new SimpleStringProperty("");
        generationProperty = new SimpleIntegerProperty(0);
        nbRemainingCellsProperty = new SimpleIntegerProperty(0);
        percentageRemainingCellsProperty = new SimpleDoubleProperty(0);

    }

    public void updateGrid(int hauteur, int largeur) {
        gpane.resize(hauteur, largeur);
        for (int i = 0; i < hauteur; i++) {
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setFillWidth(true);
            colConst.setPercentWidth(30);
            gpane.getColumnConstraints().add(colConst);
        }
        for (int i = 0; i < largeur; i++) {
            RowConstraints rowConst = new RowConstraints();
            rowConst.setFillHeight(true);
            rowConst.setPercentHeight(30);
            gpane.getRowConstraints().add(rowConst);
        }
    }

    public void update(Node child, int i, int j) {
        gpane.add(child, i, j);
    }

    public void addInput(int length, int width, int nbCells) {
        Input input = new Input(length, width, nbCells);
        listInput.add(input);
        setLength(length);
        setWidth(width);
        setNbCells(nbCells);
        input.setLength(length);
        input.setWidth(width);
        input.setNbCellsInit(nbCells);
    }

    public void addPopulation(String name, int generation, int cellsAlive, double proportion) {
        Population population = new Population(name, generation, cellsAlive, proportion);
        if (listOutput.size() == 2) {
            listOutput.setAll(population);
        } else {
            listOutput.add(population);
        }
        setName(name);
        setGeneration(generation);
        setNbRemCells(cellsAlive);
        setPercentageRemCells(proportion);
        population.setName(name);
        population.setGeneration(generation);
        population.setNbCellsAlive(cellsAlive);
        population.setProportion(proportion);

        SpinnerValueFactory<Integer> valueFactory
                = //
                new SpinnerValueFactory.IntegerSpinnerValueFactory(0, generation, 1);
        this.spinner.setValueFactory(valueFactory);

    }

    public void clearPopulation() {
        setLength(0);
        setWidth(0);
        setNbCells(0);
        setName("");
        setGeneration(0);
        setNbRemCells(0);
        setPercentageRemCells(0);
        listInput.clear();
        listOutput.clear();
        clearGrid();
    }

    public void clearGrid() {
        gpane.getChildren().clear();
    }

    public void handleNextGeneration(EventHandler<ActionEvent> event) {
        nextG.setOnAction(event);
    }

    /**
     * Consulte génération précédente
     *
     * @param event
     */
    public void handleConsulterGeneration(EventHandler<ActionEvent> event) {
        btn.setOnAction(event);
    }

    public Integer getValueSpinner() {
        return (Integer) this.spinner.getValueFactory().getValue();
    }

    /**
     * Va directement à une génération précise
     *
     * @param event
     */
    public void handleSkipGeneration(EventHandler<ActionEvent> event) {
        skipG.setOnAction(event);
    }

    public void handleResetButton(EventHandler<ActionEvent> event) {
        reset.setOnAction(event);
    }

    /**
     * Retourne l'entier entré dans le textfield
     *
     * @return un entier qui est un numéro de génération
     */
    public int getTxtNb() {
        try {
            int nb = Integer.parseInt(txtNb.getText());
            return nb;
        } catch (NumberFormatException e) {
            txtNb.setPromptText("Please enter an integer");
        }
        return 0;
    }

    @FXML
    private void handleQuit(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    private void handleAbout(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Information");
        alert.setContentText("Par défaut le jeu de la vie selon Conway suit les règles suivantes :"
                + "\n- Une cellule possédant exactement 3 voisines vivantes devient vivante."
                + "\n- Une cellule possédant 2 voisines vivantes reste dans son état actuel."
                + "\n- Une cellule ayant strictement moins de 2 ou strictement plus de 3 voisines"
                + " vivantes devient morte.");
        alert.showAndWait();
    }

    private void setName(String name) {
        nameProp.set(name);
    }

    private String getName() {
        return nameProp.get();
    }

    private SimpleStringProperty getNameProp() {
        return nameProp;
    }

    private void setGeneration(int newGeneration) {
        generationProperty.set(newGeneration);
    }

    private int getGeneration() {
        return generationProperty.get();
    }

    private SimpleIntegerProperty generationProperty() {
        return generationProperty;
    }

    private void setNbRemCells(int newNb) {
        nbRemainingCellsProperty.set(newNb);
    }

    private int getNbRemCells() {
        return nbRemainingCellsProperty.get();
    }

    private SimpleIntegerProperty nbRemCellsProp() {
        return nbRemainingCellsProperty;
    }

    private void setPercentageRemCells(double newPctg) {
        percentageRemainingCellsProperty.set(newPctg);
    }

    private double getPercentage() {
        return percentageRemainingCellsProperty.get();
    }

    private SimpleDoubleProperty percentageRemCellsProp() {
        return percentageRemainingCellsProperty;
    }

    private void setLength(int length) {
        lengthProp.set(length);
    }

    private int getLength() {
        return lengthProp.get();
    }

    private SimpleIntegerProperty lengthProp() {
        return lengthProp;
    }

    private void setWidth(int width) {
        widthProp.set(width);
    }

    private int getWidthValue() {
        return widthProp.get();
    }

    private SimpleIntegerProperty getWidthProp() {
        return widthProp;
    }

    private void setNbCells(int nbCells) {
        nbCellsProp.set(nbCells);
    }

    private int getNbCells() {
        return nbCellsProp.get();
    }

    private SimpleIntegerProperty nbCellsProp() {
        return nbCellsProp;
    }

}
