package mycomponent;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author shewolf
 */
public class Population {

    private SimpleStringProperty name;
    private SimpleIntegerProperty generation;
    private SimpleIntegerProperty nbCellsAlive;
    private SimpleDoubleProperty proportion;

    public Population() {
        this("", 0, 0, 0);
    }

    public Population(String name, int generation, int nbCellsAlive, double proportion) {
        this.name = new SimpleStringProperty(name);
        this.generation = new SimpleIntegerProperty(generation);
        this.nbCellsAlive = new SimpleIntegerProperty(nbCellsAlive);
        this.proportion = new SimpleDoubleProperty(proportion);
    }

    public SimpleStringProperty getNameProp() {
        return name;
    }

    public SimpleIntegerProperty getGenerationProp() {
        return generation;
    }

    public SimpleIntegerProperty getNbCellsAliveProp() {
        return nbCellsAlive;
    }

    public SimpleDoubleProperty getProportionProp() {
        return proportion;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public void setGeneration(int generation) {
        this.generation.set(generation);
    }

    public void setNbCellsAlive(int nbCellsAlive) {
        this.nbCellsAlive.set(nbCellsAlive);
    }

    public void setProportion(double proportion) {
        this.proportion.set(proportion);
    }

    public String getName() {
        return name.get();
    }

    public int getGeneration() {
        return generation.get();
    }

    public int getNbCellsAlive() {
        return nbCellsAlive.get();
    }

    public double getProportion() {
        return proportion.get();
    }

}
