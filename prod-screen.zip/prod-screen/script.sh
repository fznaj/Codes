#!/bin/sh
env > /tmp/env.pre.txt
. /etc/profile
export PATH=/home/pi/.nvm/versions/node/v8.12.0/bin:$PATH
export NVM_BIN=/home/pi/.nvm/versions/node/v8.12.0/bin
env > /tmp/env.post.txt
cd /home/pi/Project/prod-screen/prod-screen-server && /home/pi/.nvm/versions/node/v8.12.0/bin/node dist/index.js > /home/pi/Project/prod-screen/output.log 2>&1 &
http-server /home/pi/Project/prod-screen/prod-screen-client/dist &
