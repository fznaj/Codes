Prod-screen
===========

Doc
###

Prod-screen is a software tool that scans an ips range on a network and searches for Karos every 3 minutes.
If at least one is found, it starts fetching data from its sd card.

- Prod-screen-server

    It listens on port 8999 and starts scanning the ip addresses using ssh on the network given which is '192.168.6.0' from ip '41' untill ip '120' both included(hardcoded for now). The database configuration on the sd card is assigned to each karo found on the network. By default, the tool scans ethernet ip addresses. The Karo class[1] contains a failCount number that is set to 10 and a connectionMode that is set to 0, 1 or 2 depending on the connection mode of the karo which can either be lan, gprs or wifi respectively. The Strategy class[2] compares both scanned-karos array(or mapped-karos array) and the server's stack(the already displayed karos). It adds or updates karos found on the scanned-karos array depending on if they already exist on the stack or not, and checks the other way round, meaning it checks karos that are in the stack and that weren't found in the scan, which could either mean that they are turned off(if failCount is 0 the karo is deleted from the stack) or that they are switched to connection mode gprs. In the first case we just decrement the failCount. Otherwise we do the gprs scan on every one that wasn't found meaning every time a karo has failCount set to 7. If found with	the second scan, the karos are updated with the actual connection mode and parameters. After that they are sorted and sent to the client via websockets. If the gprs karos are back in lan or wifi mode, when scanned again everything is updated.

- Prod-screen-client

    Once the client receives the karos, they are groupped by their logo and displayed. Depending on the failCount,the opacity of the displayed info may decrease. The data displayed contains : logo,if successfully synced, amperage, connectors values, activation mode(s), languages, id, uptime date, last scan date, if calibration parameters are ok, if the the connection to nexxtmove was successful, eth and ppp addresses if any and the connection mode. Note that the connection mode and the icon next to the karo id may be different if the lan cable is still plugged in but the connection mode is set to gprs, this will set the icon to lan mode.

- Websockets

    Websockets are used here to transfer data from server to client and vice versa.

- Npm package

    The project uses a library that contains necessary types for both the server and the client. It also contains the scanner class that makes the scan possible through ssh connections.

Installation on a Raspberry Pi
##############################

Assuming we have an existing Raspbian on the Raspberry Pi's sd card and it's connected to the network, and that Node.js, typescript, angular/cli, npm are all installed on the Raspberry Pi, run the script file **update.sh** that is in the project's directory **prod-screen** so that the files are compiled and everything is up to date. To run the software at start-up, 3 files should be modified as follows : 

- **/etc/rc.local** (/home/pi/Project should be replaced by the path where the project is)

.. image:: ./rcLoc.png

- **~/.config/lxsession/LXDE-pi/autostart** (screen saver off, screen doesn't turn off after inactivity and other options)

.. image:: ./autostart.png

- **~/.config/autostart/auto.desktop** (autostart directory should probably be created. The Exec line starts Chromium browser on kiosk mode and goes to the url localhost:8080)

.. image:: ./autoDesk.png

- Save all files and exit.
- Reboot and wait.


----

[1] : prod-screen/prod-screen-server/shared/Karo.ts

[2] : prod-screen/prod-screen-server/Strategy/Strategy.ts