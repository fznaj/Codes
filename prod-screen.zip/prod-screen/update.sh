#!/bin/sh
git pull
cd ./prod-screen-server && tsc
cd ../prod-screen-client && ng build
